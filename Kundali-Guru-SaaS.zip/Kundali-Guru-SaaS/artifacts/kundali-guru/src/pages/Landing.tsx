import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Sparkles, Star, Moon, Sun, ArrowRight, ShieldCheck, ScrollText } from "lucide-react";

export default function Landing() {
  return (
    <div className="flex flex-col min-h-screen bg-background">
      {/* Hero Section */}
      <section className="relative pt-24 pb-32 overflow-hidden px-6">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-primary/10 via-background to-background" />
        <div className="max-w-4xl mx-auto relative z-10 text-center space-y-8 animate-in fade-in slide-in-from-bottom-8 duration-1000">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 text-primary text-xs font-semibold uppercase tracking-wider mb-4 border border-primary/20">
            <Sparkles className="w-3 h-3" />
            <span>Premium Vedic Astrology</span>
          </div>
          <h1 className="text-5xl md:text-7xl font-serif text-foreground leading-tight tracking-tight">
            Read the stars. <br className="hidden md:block" />
            <span className="text-primary italic">Understand your path.</span>
          </h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto leading-relaxed">
            Scholarly, precise, and deeply personal. Kundali Guru translates ancient celestial mathematics into profound clarity for your modern life journey.
          </p>
          <div className="pt-8 flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link href="/sign-up">
              <Button size="lg" className="h-14 px-8 text-lg font-medium w-full sm:w-auto group">
                Begin Your Journey <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </Button>
            </Link>
            <Link href="/sign-in">
              <Button size="lg" variant="outline" className="h-14 px-8 text-lg font-medium w-full sm:w-auto">
                Sign In
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-24 bg-card border-y border-border px-6">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16 space-y-4">
            <h2 className="text-3xl md:text-4xl font-serif text-foreground">A Higher Standard of Insight</h2>
            <p className="text-muted-foreground text-lg max-w-xl mx-auto">We do not provide novelty horoscopes. We provide mathematically rigorous astrological readings.</p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-12">
            <div className="space-y-4 text-center">
              <div className="w-16 h-16 mx-auto rounded-2xl bg-primary/10 flex items-center justify-center text-primary mb-6">
                <ScrollText className="w-8 h-8" />
              </div>
              <h3 className="text-xl font-serif text-foreground">Scholarly Accuracy</h3>
              <p className="text-muted-foreground leading-relaxed">
                Our readings are based on exact planetary ephemeris data, utilizing strict Vedic calculation methods and accurate timezones.
              </p>
            </div>
            <div className="space-y-4 text-center">
              <div className="w-16 h-16 mx-auto rounded-2xl bg-accent/10 flex items-center justify-center text-accent mb-6">
                <ShieldCheck className="w-8 h-8" />
              </div>
              <h3 className="text-xl font-serif text-foreground">Absolute Privacy</h3>
              <p className="text-muted-foreground leading-relaxed">
                Your birth details and readings are strictly confidential. We employ enterprise-grade security to protect your most personal data.
              </p>
            </div>
            <div className="space-y-4 text-center">
              <div className="w-16 h-16 mx-auto rounded-2xl bg-primary/10 flex items-center justify-center text-primary mb-6">
                <Sun className="w-8 h-8" />
              </div>
              <h3 className="text-xl font-serif text-foreground">Modern Clarity</h3>
              <p className="text-muted-foreground leading-relaxed">
                Ancient wisdom translated into accessible, practical guidance. We focus on actionable insights without jargon or fatalism.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Trust & CTA Section */}
      <section className="py-32 px-6 relative overflow-hidden">
        <div className="max-w-4xl mx-auto text-center space-y-10 relative z-10">
          <h2 className="text-4xl md:text-5xl font-serif text-foreground">Ready to seek the truth?</h2>
          <p className="text-xl text-muted-foreground">
            Join discerning individuals who rely on Kundali Guru for clarity in career, relationships, and life purpose.
          </p>
          <Link href="/sign-up">
            <Button size="lg" className="h-14 px-10 text-lg font-medium shadow-lg hover:shadow-xl transition-all">
              Create Your Free Profile
            </Button>
          </Link>
        </div>
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-primary/5 rounded-full blur-3xl -z-10" />
      </section>
    </div>
  );
}
