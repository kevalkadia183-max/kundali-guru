import {
  boolean,
  date,
  index,
  pgTable,
  text,
  timestamp,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const LEGACY_UNOWNED_USER_ID = "__legacy_unowned__";

export const profilesTable = pgTable(
  "profiles",
  {
    id: text("id").primaryKey(),
    userId: text("user_id").notNull().default(LEGACY_UNOWNED_USER_ID),
    name: text("name").notNull(),
    relationship: text("relationship").notNull(),
    birthDate: date("birth_date", { mode: "string" }).notNull(),
    birthTime: text("birth_time").notNull(),
    birthPlace: text("birth_place").notNull(),
    timezone: text("timezone").notNull(),
    isApproximateTime: boolean("is_approximate_time").notNull().default(false),
    sunSign: text("sun_sign").notNull(),
    moonSign: text("moon_sign").notNull(),
    ascendant: text("ascendant").notNull(),
    chartStatus: text("chart_status").notNull().default("ready"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [index("profiles_user_id_idx").on(table.userId)],
);

export const insertProfileSchema = createInsertSchema(profilesTable);
export type InsertProfile = z.infer<typeof insertProfileSchema>;
export type Profile = typeof profilesTable.$inferSelect;