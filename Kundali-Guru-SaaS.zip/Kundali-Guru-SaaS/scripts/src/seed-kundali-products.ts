import { getUncachableStripeClient } from "./stripeClient";

const products = [
  ["life-journey", "Life Journey", 99],
  ["karz-mukti", "Karz Mukti", 99],
  ["foreign-settlement", "Foreign Settlement Yog", 99],
  ["compatibility", "Compatibility", 99],
  ["timing", "Timing & Predictive", 99],
  ["lal-kitab", "Lal Kitab", 99],
  ["kp-system", "KP System", 99],
  ["numerology", "Numerology", 99],
  ["divisional", "Divisional Chart Report", 99],
  ["full-bundle", "Complete Kundali Collection", 799],
] as const;

const stripe = await getUncachableStripeClient();
const existing = await stripe.products.list({ active: true, limit: 100 });

for (const [kundaliProductId, name, amount] of products) {
  let product = existing.data.find(
    (item) => item.metadata.kundaliProductId === kundaliProductId,
  );
  if (!product) {
    product = await stripe.products.create({
      name,
      description: kundaliProductId === "full-bundle"
        ? "Nine complete premium Kundali Guru reports for one birth profile"
        : `Kundali Guru ${name} Vedic astrology report`,
      metadata: { kundaliProductId },
    });
  }
  const prices = await stripe.prices.list({
    product: product.id,
    active: true,
    type: "one_time",
    limit: 10,
  });
  if (!prices.data.some((price) => price.unit_amount === amount * 100 && price.currency === "inr")) {
    await stripe.prices.create({
      product: product.id,
      unit_amount: amount * 100,
      currency: "inr",
      metadata: { kundaliProductId },
    });
  }
  console.log(`Ready: ${name} ₹${amount}`);
}