import * as React from "react"
import { Slot } from "@radix-ui/react-slot"

export function TooltipProvider({
  children,
}: {
  children: React.ReactNode
  delayDuration?: number
}) {
  return <>{children}</>
}

export function Tooltip({ children }: { children: React.ReactNode }) {
  return <span className="group/tooltip relative inline-flex">{children}</span>
}

export function TooltipTrigger({
  asChild,
  children,
}: {
  asChild?: boolean
  children: React.ReactNode
}) {
  const Component = asChild ? Slot : "span"
  return <Component>{children}</Component>
}

export function TooltipContent({
  children,
  side = "right",
  className = "",
  hidden,
}: {
  children: React.ReactNode
  side?: "top" | "right" | "bottom" | "left"
  className?: string
  align?: string
  hidden?: boolean
}) {
  const sideClasses = {
    top: "bottom-full left-1/2 -translate-x-1/2 mb-2",
    right: "left-full top-1/2 -translate-y-1/2 ml-2",
    bottom: "top-full left-1/2 -translate-x-1/2 mt-2",
    left: "right-full top-1/2 -translate-y-1/2 mr-2",
  }

  return (
    <span
      className={`pointer-events-none absolute z-50 hidden whitespace-nowrap rounded-md bg-foreground px-2 py-1 text-xs text-background shadow-md group-hover/tooltip:block ${sideClasses[side]} ${className}`}
      hidden={hidden}
    >
      {children}
    </span>
  )
}
