#!/bin/bash
set -e
pnpm install --frozen-lockfile
pnpm --filter @workspace/db run push-force

psql "$DATABASE_URL" -v ON_ERROR_STOP=1 <<'SQL'
BEGIN;

WITH proven_profile_owners AS (
  SELECT profile_id, MIN(user_id) AS user_id
  FROM orders
  GROUP BY profile_id
  HAVING COUNT(DISTINCT user_id) = 1
)
UPDATE profiles AS profile
SET user_id = owner.user_id
FROM proven_profile_owners AS owner
WHERE profile.id = owner.profile_id
  AND profile.user_id = '__legacy_unowned__';

WITH proven_report_owners AS (
  SELECT report_id, MIN(user_id) AS user_id
  FROM orders
  WHERE report_id IS NOT NULL
  GROUP BY report_id
  HAVING COUNT(DISTINCT user_id) = 1
)
UPDATE reports AS report
SET user_id = owner.user_id
FROM proven_report_owners AS owner
WHERE report.id = owner.report_id
  AND report.user_id = '__legacy_unowned__';

UPDATE reports AS report
SET user_id = profile.user_id
FROM profiles AS profile
WHERE report.profile_id = profile.id
  AND report.user_id = '__legacy_unowned__'
  AND profile.user_id <> '__legacy_unowned__';

COMMIT;
SQL
