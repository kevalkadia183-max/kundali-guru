import { useListReports } from "@workspace/api-client-react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Loader2, Lock, ArrowRight, Library, Search } from "lucide-react";
import { Link } from "wouter";
import { Input } from "@/components/ui/input";
import { useState } from "react";

export default function MyReports() {
  const { data: reports, isLoading } = useListReports();
  const [searchTerm, setSearchTerm] = useState("");
  
  const filteredReports = reports?.filter(r => 
    r.productName.toLowerCase().includes(searchTerm.toLowerCase()) || 
    r.profileName.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-8 animate-in fade-in duration-500 pb-12">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-serif text-foreground">My Library</h1>
          <p className="text-muted-foreground mt-2">Your permanent collection of celestial readings.</p>
        </div>
        
        <div className="relative w-full md:w-64 shrink-0">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input 
            placeholder="Search reports or profiles..." 
            className="pl-9 bg-card"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
      </div>

      {isLoading ? (
        <div className="flex items-center justify-center py-20"><Loader2 className="w-8 h-8 animate-spin text-primary opacity-50" /></div>
      ) : (
        <div className="grid grid-cols-1 gap-4">
          {filteredReports?.map(report => (
            <Card key={report.id} className="flex flex-col sm:flex-row items-start sm:items-center justify-between p-5 gap-4 hover:border-primary/30 transition-colors">
              <div className="space-y-2 flex-1 min-w-0">
                <div className="flex items-center gap-3">
                  <h3 className="font-serif text-xl font-medium truncate">{report.productName}</h3>
                  <Badge variant={report.status === 'ready' ? "default" : "secondary"} className="font-mono text-[10px] uppercase shrink-0">
                    {report.status}
                  </Badge>
                </div>
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <span className="font-medium text-foreground">{report.profileName}</span> 
                  <span>•</span>
                  <span>{new Date(report.generatedAt).toLocaleDateString(undefined, { year: 'numeric', month: 'long', day: 'numeric' })}</span>
                </div>
                {report.summary && (
                  <p className="text-sm text-muted-foreground line-clamp-2 max-w-2xl mt-2 leading-relaxed">
                    {report.summary}
                  </p>
                )}
              </div>
              <div className="shrink-0 w-full sm:w-auto">
                {report.status === 'ready' ? (
                  <Link href={`/reports/${report.id}`}>
                    <Button variant="outline" className="w-full sm:w-auto group">
                      Open Document <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
                    </Button>
                  </Link>
                ) : report.status === 'locked' ? (
                  <Button variant="ghost" disabled className="w-full sm:w-auto gap-2 opacity-50">
                    <Lock className="w-4 h-4"/> Locked
                  </Button>
                ) : (
                  <Button variant="ghost" disabled className="w-full sm:w-auto gap-2 text-primary">
                    <Loader2 className="w-4 h-4 animate-spin"/> Generating...
                  </Button>
                )}
              </div>
            </Card>
          ))}
          {filteredReports?.length === 0 && (
            <div className="text-center py-20 bg-card border border-dashed border-border rounded-xl flex flex-col items-center justify-center space-y-4">
              <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center text-muted-foreground">
                <Library className="w-8 h-8" />
              </div>
              <div>
                <h3 className="font-serif text-xl text-foreground mb-2">No documents found</h3>
                <p className="text-muted-foreground text-sm max-w-md mx-auto">
                  {searchTerm ? "No readings match your search criteria." : "You haven't requested any readings yet. Visit the Reading Room to begin."}
                </p>
              </div>
              {!searchTerm && (
                <Link href="/reports">
                  <Button variant="outline" className="mt-4">Go to Reading Room</Button>
                </Link>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
