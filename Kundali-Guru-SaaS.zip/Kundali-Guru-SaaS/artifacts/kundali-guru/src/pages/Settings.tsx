import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Bell, Moon, Sun, Monitor, ShieldCheck, Mail } from "lucide-react";
import { useState, useEffect } from "react";

export default function Settings() {
  const [theme, setTheme] = useState("system");
  
  useEffect(() => {
    const isDark = document.documentElement.classList.contains("dark");
    setTheme(isDark ? "dark" : "light");
  }, []);
  
  const handleThemeChange = (value: string) => {
    setTheme(value);
    if (value === "dark") {
      document.documentElement.classList.add("dark");
    } else if (value === "light") {
      document.documentElement.classList.remove("dark");
    }
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-500 max-w-3xl">
      <div>
        <h1 className="text-3xl font-serif text-foreground">Settings</h1>
        <p className="text-muted-foreground mt-2 text-lg">Preferences for your reading room environment.</p>
      </div>

      <div className="space-y-6">
        <Card className="bg-card border-border">
          <CardHeader>
            <CardTitle className="font-serif text-xl">Appearance</CardTitle>
            <CardDescription>
              Customize the visual aesthetic of the application.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <p className="font-medium text-foreground">Theme</p>
                <p className="text-sm text-muted-foreground">Select your preferred illumination.</p>
              </div>
              <Select value={theme} onValueChange={handleThemeChange}>
                <SelectTrigger className="w-32">
                  <SelectValue placeholder="Theme" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="light"><div className="flex items-center gap-2"><Sun className="w-4 h-4"/> Light</div></SelectItem>
                  <SelectItem value="dark"><div className="flex items-center gap-2"><Moon className="w-4 h-4"/> Dark</div></SelectItem>
                  <SelectItem value="system"><div className="flex items-center gap-2"><Monitor className="w-4 h-4"/> System</div></SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="flex items-center justify-between border-t border-border pt-6">
              <div className="space-y-1">
                <p className="font-medium text-foreground">Astrological Chart Style</p>
                <p className="text-sm text-muted-foreground">South Indian (Diamond) or North Indian (Square).</p>
              </div>
              <Select defaultValue="north">
                <SelectTrigger className="w-32">
                  <SelectValue placeholder="Style" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="north">North Indian</SelectItem>
                  <SelectItem value="south">South Indian</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardHeader>
            <CardTitle className="font-serif text-xl">Notifications</CardTitle>
            <CardDescription>
              When and how we should contact you.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Mail className="w-5 h-5 text-muted-foreground" />
                <div className="space-y-1">
                  <p className="font-medium text-foreground">Report Ready Alerts</p>
                  <p className="text-sm text-muted-foreground">Receive an email when your celestial reading is complete.</p>
                </div>
              </div>
              <Switch defaultChecked />
            </div>
            <div className="flex items-center justify-between border-t border-border pt-6">
              <div className="flex items-center gap-3">
                <Bell className="w-5 h-5 text-muted-foreground" />
                <div className="space-y-1">
                  <p className="font-medium text-foreground">Transit Highlights</p>
                  <p className="text-sm text-muted-foreground">Monthly notifications about major planetary shifts.</p>
                </div>
              </div>
              <Switch defaultChecked />
            </div>
          </CardContent>
        </Card>
        
        <div className="flex justify-end">
          <Button variant="default">Save Preferences</Button>
        </div>
      </div>
    </div>
  );
}
