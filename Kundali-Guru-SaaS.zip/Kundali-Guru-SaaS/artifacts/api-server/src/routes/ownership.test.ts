import assert from "node:assert/strict";
import http from "node:http";
import { after, before, describe, test } from "node:test";
import express, { type RequestHandler } from "express";
import { createClerkClient } from "@clerk/express";
import { count, eq, inArray } from "drizzle-orm";
import {
  db,
  ordersTable,
  profilesTable,
  reportsTable,
} from "@workspace/db";
import kundaliRouter from "./kundali";
import { createCheckoutRouter } from "./checkout";
import { createAdminRouter } from "./admin";

const USER_A = "ownership-test-user-a";
const USER_B = "ownership-test-user-b";
const ADMIN_USER = "ownership-test-admin";
const FIXTURE_ORDER_PREFIX = "ownership-test-order:";

type TestResponse = {
  status: number;
  body: any;
};

type FakeSession = {
  client_reference_id: string;
  payment_status: "paid" | "unpaid";
  metadata: Record<string, string>;
};

const sessions = new Map<string, FakeSession>();
let server: http.Server;
let baseUrl: string;
let profileA: string;
let profileB: string;
let reportA: string;
let reportB: string;
let deleteOnlyProfile: string;
let deleteOnlyProfileB: string;

async function deleteFixtures() {
  await db.delete(ordersTable).where(inArray(ordersTable.userId, [USER_A, USER_B]));
  await db.delete(reportsTable).where(inArray(reportsTable.userId, [USER_A, USER_B]));
  await db.delete(profilesTable).where(inArray(profilesTable.userId, [USER_A, USER_B]));
}

function testAuthMiddleware(): RequestHandler {
  return (req, _res, next) => {
    const header = req.headers["x-test-user-id"];
    const userId = typeof header === "string" ? header : null;
    const auth = Object.assign(
      () => ({
        userId,
        tokenType: "session_token",
        sessionClaims: userId ? { sub: userId } : null,
      }),
      { [Symbol.for("@clerk/express.auth")]: true },
    );
    (req as unknown as { auth: typeof auth }).auth = auth;
    (req as unknown as { log: { warn: () => void } }).log = { warn: () => {} };
    next();
  };
}

function fakeStripe() {
  return {
    checkout: {
      sessions: {
        create: async (params: {
          client_reference_id?: string;
          metadata?: Record<string, string>;
        }) => {
          const id = `${FIXTURE_ORDER_PREFIX}${sessions.size + 1}`;
          sessions.set(id, {
            client_reference_id: params.client_reference_id ?? "",
            payment_status: "paid",
            metadata: params.metadata ?? {},
          });
          return { id, url: `https://checkout.test/${id}` };
        },
        retrieve: async (id: string) => ({
          id,
          ...(sessions.get(id) ?? {
            client_reference_id: null,
            payment_status: "unpaid",
            metadata: {},
          }),
        }),
      },
    },
  };
}

function createTestApp() {
  const stripe = fakeStripe();
  const app = express();
  app.use(express.json());
  app.use(testAuthMiddleware());
  app.use(kundaliRouter);
  app.use(createCheckoutRouter({
    findPrice: async () => ({
      stripe: stripe as never,
      price: { id: "test-price" } as never,
    }),
    getStripeClient: async () => stripe as never,
  }));
  app.use(createAdminRouter({
    clerkClientFactory: (() => ({
      users: {
        getUser: async (id: string) => ({
          id,
          publicMetadata: { role: id === ADMIN_USER ? "admin" : "user" },
          firstName: id === ADMIN_USER ? "Test" : "Customer",
          lastName: id === ADMIN_USER ? "Admin" : id.slice(-1).toUpperCase(),
          createdAt: Date.now(),
          primaryEmailAddressId: `${id}-email`,
          emailAddresses: [{ id: `${id}-email`, emailAddress: `${id}@test.invalid` }],
        }),
        getUserList: async () => ({
          data: [USER_A, USER_B, ADMIN_USER].map((id) => ({
            id,
            publicMetadata: { role: id === ADMIN_USER ? "admin" : "user" },
            firstName: id === ADMIN_USER ? "Test" : "Customer",
            lastName: id === ADMIN_USER ? "Admin" : id.slice(-1).toUpperCase(),
            createdAt: Date.now(),
            primaryEmailAddressId: `${id}-email`,
            emailAddresses: [{ id: `${id}-email`, emailAddress: `${id}@test.invalid` }],
          })),
          totalCount: 3,
        }),
      },
    }) as unknown as ReturnType<typeof createClerkClient>),
  }));
  return app;
}

async function request(
  path: string,
  options: { userId?: string; method?: string; body?: unknown } = {},
): Promise<TestResponse> {
  const response = await fetch(`${baseUrl}${path}`, {
    method: options.method ?? "GET",
    headers: {
      ...(options.userId ? { "x-test-user-id": options.userId } : {}),
      ...(options.body ? { "content-type": "application/json" } : {}),
    },
    body: options.body ? JSON.stringify(options.body) : undefined,
  });
  const text = await response.text();
  return { status: response.status, body: text ? JSON.parse(text) : undefined };
}

async function createProfile(userId: string, name: string) {
  const response = await request("/profiles", {
    userId,
    method: "POST",
    body: {
      name,
      relationship: "self",
      birthDate: "1990-01-15",
      birthTime: "09:30",
      birthPlace: "Ahmedabad, India",
      timezone: "Asia/Kolkata",
      isApproximateTime: false,
    },
  });
  assert.equal(response.status, 201);
  return response.body.id as string;
}

async function generateFreeReport(userId: string, profileId: string, question: string) {
  const response = await request("/reports/generate", {
    userId,
    method: "POST",
    body: { profileId, productId: "generic", question, quickAnswers: [] },
  });
  assert.equal(response.status, 201);
  return response.body.id as string;
}

before(async () => {
  await deleteFixtures();
  sessions.clear();
  const app = createTestApp();
  await new Promise<void>((resolve) => {
    server = app.listen(0, "127.0.0.1", () => resolve());
  });
  const address = server.address();
  assert.ok(address && typeof address === "object");
  baseUrl = `http://127.0.0.1:${address.port}`;

  profileA = await createProfile(USER_A, "Customer A");
  profileB = await createProfile(USER_B, "Customer B");
  deleteOnlyProfile = await createProfile(USER_A, "Customer A Delete Me");
  deleteOnlyProfileB = await createProfile(USER_B, "Customer B Delete Me");
  reportA = await generateFreeReport(USER_A, profileA, "A's private question");
  reportB = await generateFreeReport(USER_B, profileB, "B's private question");
});

after(async () => {
  await new Promise<void>((resolve, reject) => server.close((error) => error ? reject(error) : resolve()));
  await deleteFixtures();
});

describe("customer ownership boundaries", () => {
  test("rejects unauthenticated customer endpoints with 401", async () => {
    const requests = await Promise.all([
      request("/dashboard"),
      request("/activity"),
      request("/profiles"),
      request(`/profiles/${profileA}`),
      request("/reports"),
      request(`/reports/${reportA}`),
      request("/reports/generate", {
        method: "POST",
      body: { profileId: profileA, productId: "generic", question: "", quickAnswers: [] },
      }),
      request("/checkout", {
        method: "POST",
        body: { profileId: profileA, productId: "life-journey" },
      }),
      request("/checkout/not-a-real-session"),
    ]);
    assert.deepEqual(requests.map((response) => response.status), Array(9).fill(401));
  });

  test("lists and views only the signed-in customer's profiles and reports", async () => {
    const [profilesA, profilesB, reportsA, reportsB, dashboardA, activityB] = await Promise.all([
      request("/profiles", { userId: USER_A }),
      request("/profiles", { userId: USER_B }),
      request("/reports", { userId: USER_A }),
      request("/reports", { userId: USER_B }),
      request("/dashboard", { userId: USER_A }),
      request("/activity", { userId: USER_B }),
    ]);

    assert.deepEqual(profilesA.body.map((profile: { id: string }) => profile.id).sort(), [profileA, deleteOnlyProfile].sort());
    assert.deepEqual(profilesB.body.map((profile: { id: string }) => profile.id).sort(), [profileB, deleteOnlyProfileB].sort());
    assert.deepEqual(reportsA.body.map((report: { id: string }) => report.id), [reportA]);
    assert.deepEqual(reportsB.body.map((report: { id: string }) => report.id), [reportB]);
    assert.equal(dashboardA.body.activeProfile.id, profileA);
    assert.equal(dashboardA.body.stats.profiles, 2);
    assert.equal(dashboardA.body.stats.reportsReady, 1);
    assert.match(activityB.body[0].description, /Customer B/);

    const [profileCrossRead, reportCrossRead] = await Promise.all([
      request(`/profiles/${profileB}`, { userId: USER_A }),
      request(`/reports/${reportB}`, { userId: USER_A }),
    ]);
    assert.equal(profileCrossRead.status, 404);
    assert.equal(reportCrossRead.status, 404);
  });

  test("generates and deletes only records owned by the requesting customer", async () => {
    const crossGenerate = await request("/reports/generate", {
      userId: USER_A,
      method: "POST",
      body: {
        profileId: profileB,
        productId: "generic",
        question: "should not work",
        quickAnswers: [],
      },
    });
    assert.equal(crossGenerate.status, 404);

    const ownGenerate = await generateFreeReport(USER_B, profileB, "B's second private question");
    const ownReport = await request(`/reports/${ownGenerate}`, { userId: USER_B });
    assert.equal(ownReport.status, 200);
    assert.equal(ownReport.body.profileId, profileB);

    const crossDelete = await request(`/profiles/${deleteOnlyProfile}`, {
      userId: USER_B,
      method: "DELETE",
    });
    assert.equal(crossDelete.status, 404);
    const crossDeleteReverse = await request(`/profiles/${deleteOnlyProfileB}`, {
      userId: USER_A,
      method: "DELETE",
    });
    assert.equal(crossDeleteReverse.status, 404);
    const ownDelete = await request(`/profiles/${deleteOnlyProfile}`, {
      userId: USER_A,
      method: "DELETE",
    });
    assert.equal(ownDelete.status, 204);
    const ownDeleteReverse = await request(`/profiles/${deleteOnlyProfileB}`, {
      userId: USER_B,
      method: "DELETE",
    });
    assert.equal(ownDeleteReverse.status, 204);
    const deletedRead = await request(`/profiles/${deleteOnlyProfile}`, { userId: USER_A });
    assert.equal(deletedRead.status, 404);
  });

  test("creates paid checkout sessions only for owned profiles", async () => {
    const crossCheckout = await request("/checkout", {
      userId: USER_A,
      method: "POST",
      body: { profileId: profileB, productId: "life-journey" },
    });
    assert.equal(crossCheckout.status, 400);

    const ownCheckout = await request("/checkout", {
      userId: USER_B,
      method: "POST",
      body: { profileId: profileB, productId: "life-journey" },
    });
    assert.equal(ownCheckout.status, 200);
    assert.ok(ownCheckout.body.sessionId);
    assert.match(ownCheckout.body.url, /checkout\.test/);

    const crossSession = await request(`/checkout/${ownCheckout.body.sessionId}`, { userId: USER_A });
    assert.deepEqual(crossSession, { status: 200, body: { status: "pending", reportIds: [] } });

    const ownSession = await request(`/checkout/${ownCheckout.body.sessionId}`, { userId: USER_B });
    assert.equal(ownSession.status, 200);
    assert.equal(ownSession.body.status, "paid");
    assert.equal(ownSession.body.reportIds.length, 1);
    const paidReport = await request(`/reports/${ownSession.body.reportIds[0]}`, { userId: USER_B });
    assert.equal(paidReport.status, 200);
    assert.equal(paidReport.body.profileId, profileB);
  });
});

test("authorized administrators see global totals across customers", async () => {
  const [profileCount] = await db.select({ value: count() }).from(profilesTable);
  const [reportCount] = await db.select({ value: count() }).from(reportsTable).where(
    eq(reportsTable.userId, USER_A),
  );
  const [allReports] = await db.select({ value: count() }).from(reportsTable);
  const overview = await request("/admin/overview", { userId: ADMIN_USER });

  assert.equal(overview.status, 200);
  assert.equal(overview.body.stats.profiles, Number(profileCount.value));
  assert.equal(overview.body.stats.reports, Number(allReports.value));
  assert.ok(Number(allReports.value) > Number(reportCount.value));
  assert.equal(overview.body.stats.users, 3);
});