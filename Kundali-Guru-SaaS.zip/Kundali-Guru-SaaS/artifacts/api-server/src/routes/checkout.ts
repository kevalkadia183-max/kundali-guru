import { getAuth } from "@clerk/express";
import { and, eq } from "drizzle-orm";
import { Router, type IRouter } from "express";
import { randomUUID } from "node:crypto";
import {
  db,
  ordersTable,
  profilesTable,
  reportsTable,
} from "@workspace/db";
import { getUncachableStripeClient } from "../stripeClient";
import {
  buildReportSections,
  disclaimer,
  lifeJourneyFor,
  reportCatalog,
} from "./kundali";

function requireUserId(req: Parameters<typeof getAuth>[0]) {
  return getAuth(req).userId ?? undefined;
}

async function findPrice(productId: string) {
  const stripe = await getUncachableStripeClient();
  const products = await stripe.products.list({ active: true, limit: 100 });
  const product = products.data.find(
    (item) => item.metadata.kundaliProductId === productId,
  );
  if (!product) throw new Error("Stripe product is not configured");
  const prices = await stripe.prices.list({
    product: product.id,
    active: true,
    type: "one_time",
    limit: 10,
  });
  const price = prices.data[0];
  if (!price) throw new Error("Stripe price is not configured");
  return { stripe, price };
}

type CheckoutRouterOptions = {
  findPrice?: typeof findPrice;
  getStripeClient?: typeof getUncachableStripeClient;
};

export function createCheckoutRouter({
  findPrice: findPriceOverride = findPrice,
  getStripeClient = getUncachableStripeClient,
}: CheckoutRouterOptions = {}): IRouter {
  const router: IRouter = Router();

  router.post("/checkout", async (req, res) => {
  const userId = requireUserId(req);
  if (!userId) return res.status(401).json({ error: "Unauthorized" });

  const { productId, profileId, question = "" } = req.body as {
    productId?: string;
    profileId?: string;
    question?: string;
  };
  const product = reportCatalog.find((item) => item.id === productId);
  const [profile] = profileId
    ? await db.select().from(profilesTable).where(and(
      eq(profilesTable.id, profileId),
      eq(profilesTable.userId, userId),
    ))
    : [];
  if (!product || product.isFree || !profile) {
    return res.status(400).json({ error: "Invalid checkout request" });
  }

  try {
    const { stripe, price } = await findPriceOverride(product.id);
    const origin = `${req.protocol}://${req.get("host")}`;
    const session = await stripe.checkout.sessions.create({
      mode: "payment",
      line_items: [{ price: price.id, quantity: 1 }],
      success_url: `${origin}/reports?checkout=success&session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${origin}/reports?checkout=cancelled`,
      client_reference_id: userId,
      metadata: {
        userId,
        productId: product.id,
        profileId: profile.id,
        question: question.slice(0, 450),
      },
      payment_intent_data: {
        metadata: { userId, productId: product.id, profileId: profile.id },
      },
    });
    if (!session.url) throw new Error("Stripe did not return a checkout URL");
    return res.json({ url: session.url, sessionId: session.id });
  } catch (error) {
    return res.status(502).json({
      error: error instanceof Error ? error.message : "Checkout unavailable",
    });
  }
  });

  router.get("/checkout/:sessionId", async (req, res) => {
  const userId = requireUserId(req);
  if (!userId) return res.status(401).json({ error: "Unauthorized" });
  const stripe = await getStripeClient();
  const session = await stripe.checkout.sessions.retrieve(req.params.sessionId);
  if (session.client_reference_id !== userId || session.payment_status !== "paid") {
    return res.json({ status: "pending", reportIds: [] });
  }

  const productId = session.metadata?.productId;
  const profileId = session.metadata?.profileId;
  const question = session.metadata?.question ?? "";
  const [profile] = profileId
    ? await db.select().from(profilesTable).where(and(
      eq(profilesTable.id, profileId),
      eq(profilesTable.userId, userId),
    ))
    : [];
  if (!productId || !profile) {
    return res.status(400).json({ error: "Checkout metadata is incomplete" });
  }

  const purchasedProducts = productId === "full-bundle"
    ? reportCatalog.filter((item) => !item.isFree && !item.isBundle)
    : reportCatalog.filter((item) => item.id === productId);
  const reportIds: string[] = [];

  for (const product of purchasedProducts) {
    const orderId = `${session.id}:${product.id}`;
    const [existing] = await db
      .select()
      .from(ordersTable)
      .where(and(eq(ordersTable.id, orderId), eq(ordersTable.userId, userId)));
    if (existing?.reportId) {
      reportIds.push(existing.reportId);
      continue;
    }

    const reportId = randomUUID();
    await db.insert(reportsTable).values({
      id: reportId,
      userId,
      productId: product.id,
      productName: product.name,
      profileId: profile.id,
      profileName: profile.name,
      status: "ready",
      summary: `${profile.name}'s ${product.name} reading highlights a disciplined growth phase shaped by Jupiter’s expansion and Saturn’s demand for structure.`,
      question,
      sections: buildReportSections(profile, question),
      lifeJourney: product.id === "life-journey" ? lifeJourneyFor(profile.birthDate) : [],
      disclaimer,
    });
    await db.insert(ordersTable).values({
      id: orderId,
      userId,
      profileId: profile.id,
      productId: product.id,
      stripeSessionId: session.id,
      amount: product.price,
      question,
      reportId,
    }).onConflictDoNothing();
    reportIds.push(reportId);
  }

  return res.json({ status: "paid", reportIds });
  });

  return router;
}

export default createCheckoutRouter();