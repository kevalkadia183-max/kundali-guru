import { ShieldCheck } from "lucide-react";

export default function Privacy() {
  return (
    <div className="max-w-3xl mx-auto py-16 px-6">
      <div className="text-center space-y-4 mb-16">
        <div className="w-16 h-16 bg-primary/10 text-primary rounded-full flex items-center justify-center mx-auto mb-6">
          <ShieldCheck className="w-8 h-8" />
        </div>
        <h1 className="text-4xl md:text-5xl font-serif text-foreground">Privacy Policy</h1>
        <p className="text-xl text-muted-foreground">Your celestial data is yours alone.</p>
      </div>

      <div className="prose prose-stone dark:prose-invert max-w-none space-y-8 font-serif leading-relaxed">
        <section>
          <h2 className="text-2xl text-foreground font-serif">1. Introduction</h2>
          <p>
            At Kundali Guru, we handle sensitive astrological information—date, time, and location of birth. 
            We believe that your celestial identity is highly personal. This Privacy Policy outlines how we protect it.
          </p>
        </section>

        <section>
          <h2 className="text-2xl text-foreground font-serif">2. Information Collection</h2>
          <p>
            We collect profile information necessary to cast accurate charts: names, birth dates, birth times, and birthplaces. 
            We also collect account information such as your email address for authentication purposes.
          </p>
        </section>

        <section>
          <h2 className="text-2xl text-foreground font-serif">3. Data Usage & Security</h2>
          <p>
            Your birth details are used exclusively for calculating planetary ephemeris data and generating your requested reports. 
            We use industry-standard encryption to store all profile data. We do not sell your personal or astrological data to any third party.
          </p>
        </section>
        
        <section>
          <h2 className="text-2xl text-foreground font-serif">4. Data Deletion</h2>
          <p>
            You retain the right to delete your profile data at any time through your account settings. 
            Upon deletion, all associated celestial calculations and reading documents will be permanently removed from our active servers.
          </p>
        </section>
      </div>
    </div>
  );
}
