import { createClerkClient, getAuth } from "@clerk/express";
import { Router, type IRouter } from "express";
import { desc, eq } from "drizzle-orm";
import { GetAdminOverviewResponse } from "@workspace/api-zod";
import { db, ordersTable, profilesTable, reportsTable } from "@workspace/db";
import { reportCatalog } from "./kundali";

function clerk() {
  return createClerkClient({ secretKey: process.env.CLERK_SECRET_KEY });
}

type AdminRouterOptions = {
  clerkClientFactory?: typeof clerk;
};

export function createAdminRouter({
  clerkClientFactory = clerk,
}: AdminRouterOptions = {}): IRouter {
  const router: IRouter = Router();

  router.get("/admin/overview", async (req, res): Promise<void> => {
  const userId = getAuth(req).userId;
  if (!userId) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }

  const client = clerkClientFactory();
  const currentUser = await client.users.getUser(userId);
  if (currentUser.publicMetadata?.role !== "admin") {
    res.status(403).json({ error: "Administrator access required" });
    return;
  }

  const users = [];
  let offset = 0;
  let totalCount = 0;
  do {
    const page = await client.users.getUserList({ limit: 100, offset });
    users.push(...page.data);
    totalCount = page.totalCount;
    offset += page.data.length;
  } while (offset < totalCount);

  const [profiles, reports, orders] = await Promise.all([
    db.select({ id: profilesTable.id }).from(profilesTable),
    db.select().from(reportsTable).orderBy(desc(reportsTable.generatedAt)),
    db.select().from(ordersTable).orderBy(desc(ordersTable.createdAt)),
  ]);

  const emailByUserId = new Map(
    users.map((user) => [
      user.id,
      user.emailAddresses.find((email) => email.id === user.primaryEmailAddressId)?.emailAddress
        ?? user.emailAddresses[0]?.emailAddress
        ?? "No email",
    ]),
  );
  const paidOrders = orders.filter((order) => order.status === "paid");
  const spending = new Map<string, { reports: number; amount: number }>();
  for (const order of paidOrders) {
    const current = spending.get(order.userId) ?? { reports: 0, amount: 0 };
    current.reports += 1;
    current.amount += order.amount;
    spending.set(order.userId, current);
  }
  const productName = new Map(reportCatalog.map((product) => [product.id, product.name]));

  res.json(GetAdminOverviewResponse.parse({
    stats: {
      users: users.length,
      profiles: profiles.length,
      reports: reports.length,
      paidOrders: paidOrders.length,
      paidRevenueInr: paidOrders.reduce((sum, order) => sum + order.amount, 0),
    },
    users: users.map((user) => ({
      id: user.id,
      name: [user.firstName, user.lastName].filter(Boolean).join(" ") || "Unnamed user",
      email: emailByUserId.get(user.id) ?? "No email",
      role: user.publicMetadata?.role === "admin" ? "Admin" : "User",
      joinedAt: new Date(user.createdAt),
      reportsPurchased: spending.get(user.id)?.reports ?? 0,
      amountSpentInr: spending.get(user.id)?.amount ?? 0,
    })),
    recentOrders: orders.slice(0, 10).map((order) => ({
      id: order.id,
      userEmail: emailByUserId.get(order.userId) ?? "Unknown user",
      productName: productName.get(order.productId) ?? order.productId,
      amountInr: order.amount,
      status: order.status,
      createdAt: order.createdAt,
    })),
    recentReports: reports.slice(0, 10).map((report) => ({
      id: report.id,
      profileName: report.profileName,
      productName: report.productName,
      status: report.status,
      generatedAt: report.generatedAt,
    })),
  }));
  });

  return router;
}

export default createAdminRouter();