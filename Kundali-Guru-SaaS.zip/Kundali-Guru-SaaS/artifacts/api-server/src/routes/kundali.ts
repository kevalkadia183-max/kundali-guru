import { randomUUID } from "node:crypto";
import { Router, type IRouter } from "express";
import { getAuth } from "@clerk/express";
import { and, desc, eq } from "drizzle-orm";
import {
  CreateProfileBody,
  CreateProfileResponse,
  UpdateProfileBody,
  UpdateProfileResponse,
  GenerateReportBody,
  GenerateReportResponse,
  GetActivityResponse,
  GetDashboardResponse,
  GetProfileParams,
  GetProfileResponse,
  GetReportParams,
  GetReportResponse,
  ListProfilesResponse,
  ListReportCatalogResponse,
  ListReportsResponse,
} from "@workspace/api-zod";
import { db, profilesTable, reportsTable } from "@workspace/db";

const router: IRouter = Router();

function requireUserId(req: Parameters<typeof getAuth>[0]) {
  return getAuth(req).userId ?? undefined;
}

export const reportCatalog = [
  {
    id: "generic",
    slug: "generic-report",
    name: "Your Kundali Blueprint",
    category: "Foundation",
    description: "A clear, beautifully structured reading of your chart, strengths, dashas, yogas, and life themes.",
    price: 0,
    duration: "12–15 min read",
    isFree: true,
    isFeatured: false,
    isBundle: false,
    savings: 0,
    status: "available" as const,
  },
  {
    id: "life-journey",
    slug: "life-journey",
    name: "Life Journey",
    category: "Flagship",
    description: "Your career, love, money, family, education, and wellbeing across the major chapters of your life.",
    price: 99,
    duration: "30–35 min read",
    isFree: false,
    isFeatured: true,
    isBundle: false,
    savings: 0,
    status: "available" as const,
  },
  {
    id: "karz-mukti",
    slug: "karz-mukti",
    name: "Karz Mukti",
    category: "Money",
    description: "Understand debt patterns, financial pressure periods, and practical remedies through your chart.",
    price: 99,
    duration: "18–22 min read",
    isFree: false,
    isFeatured: false,
    isBundle: false,
    savings: 0,
    status: "available" as const,
  },
  {
    id: "foreign-settlement",
    slug: "foreign-settlement",
    name: "Foreign Settlement Yog",
    category: "Travel",
    description: "Explore the strength, timing, and likely purpose of foreign travel or long-term settlement.",
    price: 99,
    duration: "16–20 min read",
    isFree: false,
    isFeatured: false,
    isBundle: false,
    savings: 0,
    status: "available" as const,
  },
  {
    id: "compatibility",
    slug: "compatibility",
    name: "Compatibility",
    category: "Relationships",
    description: "A nuanced relationship reading with Guna Milan, emotional dynamics, and long-term harmony.",
    price: 99,
    duration: "22–25 min read",
    isFree: false,
    isFeatured: false,
    isBundle: false,
    savings: 0,
    status: "available" as const,
  },
  {
    id: "timing",
    slug: "timing-predictive",
    name: "Timing & Predictive",
    category: "Forecast",
    description: "A focused snapshot of current transits, Varshphal themes, and your most supportive windows.",
    price: 99,
    duration: "20–24 min read",
    isFree: false,
    isFeatured: false,
    isBundle: false,
    savings: 0,
    status: "available" as const,
  },
  {
    id: "lal-kitab",
    slug: "lal-kitab",
    name: "Lal Kitab",
    category: "Remedial",
    description: "Distinct Lal Kitab placements, dasha themes, problem patterns, and optional traditional remedies.",
    price: 99,
    duration: "18–22 min read",
    isFree: false,
    isFeatured: false,
    isBundle: false,
    savings: 0,
    status: "available" as const,
  },
  {
    id: "kp-system",
    slug: "kp-system",
    name: "KP System",
    category: "Technical",
    description: "Placidus cusps and star-sub lord analysis for focused, question-oriented predictive guidance.",
    price: 99,
    duration: "20–24 min read",
    isFree: false,
    isFeatured: false,
    isBundle: false,
    savings: 0,
    status: "available" as const,
  },
  {
    id: "numerology",
    slug: "numerology",
    name: "Numerology",
    category: "Technical",
    description: "Chaldean name number, birth number, core tendencies, favorable cycles, and practical alignment.",
    price: 99,
    duration: "14–18 min read",
    isFree: false,
    isFeatured: false,
    isBundle: false,
    savings: 0,
    status: "available" as const,
  },
  {
    id: "divisional",
    slug: "divisional-charts",
    name: "Divisional Chart Report",
    category: "Technical",
    description: "All sixteen Shodashvarga charts with focused interpretation of Navamsa, Dashamsa, and Saptamsa.",
    price: 99,
    duration: "25–30 min read",
    isFree: false,
    isFeatured: false,
    isBundle: false,
    savings: 0,
    status: "available" as const,
  },
  {
    id: "full-bundle",
    slug: "full-bundle",
    name: "Complete Kundali Collection",
    category: "Best value",
    description: "Unlock all nine paid reports for one profile, plus a consolidated and de-duplicated Summary of Remedies.",
    price: 799,
    duration: "9 complete readings",
    isFree: false,
    isFeatured: true,
    isBundle: true,
    savings: 92,
    status: "available" as const,
  },
];

export const disclaimer =
  "For guidance and reflective purposes only. Not a substitute for professional financial, legal, or medical advice.";

const lifeDomains = [
  ["career", "Career", "Saturn rewards patient mastery while Jupiter expands your professional reach.", "Jupiter–Saturn supports role clarity and durable authority through October 2027.", "March 2028 to July 2030 favors leadership, independent consulting, and higher-responsibility work.", "Mars influencing the 10th can create urgency and conflict with authority.", "Recite Om Sham Shanicharaya Namah 108 times on Saturdays; document decisions before acting; optional sesame-oil lamp practice."],
  ["education", "Education", "Mercury and Jupiter make structured learning especially productive.", "The current period favors certification, writing, teaching, and technical depth.", "August 2027 to December 2029 is a strong window for advanced study.", "Mercury under Saturn’s aspect can cause over-analysis and delayed completion.", "Use Wednesday study sprints, teach one concept weekly, and optionally donate stationery to students."],
  ["love", "Love", "Venus supports honesty and a more mature expression of affection.", "The present cycle asks for fewer assumptions and clearer emotional language.", "Late 2027 through mid-2029 improves warmth and relationship visibility.", "Rahu’s influence can magnify attraction before compatibility is proven.", "Repeat Om Shum Shukraya Namah on Fridays, schedule direct conversations, and optionally offer white flowers in prayer."],
  ["marriage", "Marriage", "The 7th-house pattern favors partnership built on shared responsibility.", "Current transits help define commitment standards and family expectations.", "January 2028 to September 2029 is a constructive commitment window.", "Saturn can delay decisions until practical concerns feel resolved.", "Practice a Friday gratitude ritual, align on finances early, and keep traditional remedies optional."],
  ["children", "Children", "Jupiter supports patient guidance and long-term family planning.", "The current dasha emphasizes responsibility around the 5th-house themes.", "A supportive family window opens from 2028 into 2030.", "Saturn’s aspect may make timing feel slower than expected.", "Chant a Jupiter mantra on Thursdays, create stable routines, and seek qualified medical advice for health questions."],
  ["money", "Money", "Your 2nd and 11th house pattern rewards steady accumulation over speculation.", "The current period is suited to simplifying obligations and rebuilding reserves.", "April 2027 to November 2029 favors income expansion with disciplined planning.", "Mars–Rahu periods can tempt reactive spending or risky leverage.", "Review cash flow every Tuesday, automate savings, and optionally donate red lentils as a traditional practice."],
  ["health", "Health", "The chart supports wellbeing through rhythm, rest, and sustainable routines rather than extremes.", "Saturn asks for consistency and appropriate professional care when needed.", "From late 2027, energy becomes easier to manage with established habits.", "6th-house pressure can show as overwork; this is not a diagnosis.", "Use a gentle Saturday routine, protect sleep, and consult licensed health professionals for any symptoms."],
] as const;

export function lifeJourneyFor(birthDate: string) {
  const birthYear = Number(birthDate.slice(0, 4));
  return lifeDomains.map(([id, name, summary, currentPeriod, futureWindow, challenge, remedy], domainIndex) => ({
    id,
    name,
    summary,
    currentPeriod,
    futureWindow,
    challenge,
    remedy,
    points: Array.from({ length: 11 }, (_, pointIndex) => {
      const age = pointIndex * 8;
      const base = Math.sin((pointIndex + domainIndex) * 0.8) * 3;
      return {
        age,
        year: birthYear + age,
        score: Math.max(-5, Math.min(5, Math.round(base + ((pointIndex + domainIndex) % 3) - 1))),
        period: ["Venus", "Sun", "Moon", "Mars", "Rahu", "Jupiter", "Saturn", "Mercury", "Ketu", "Venus", "Sun"][pointIndex],
      };
    }),
  }));
}

export function buildReportSections(profile: {
  moonSign: string;
  ascendant: string;
}, question: string) {
  return [
    { id: "snapshot", eyebrow: "1 · Snapshot", title: "Your present chapter", tone: "positive" as const, content: "You are entering a constructive period where disciplined effort and clearer judgment work together. What feels slower than expected is building a durable foundation rather than blocking progress." },
    { id: "factors", eyebrow: "2 · Relevant chart factors", title: "The planets driving this theme", tone: "neutral" as const, content: `Your ${profile.moonSign} Moon places emotional security at the center of major decisions, while ${profile.ascendant} rising makes Jupiter the guide for long-range growth. Saturn’s influence on the 11th-house pattern rewards networks, expertise, and goals pursued with patience.` },
    { id: "past", eyebrow: "3 · Past phases", title: "How the pattern developed", tone: "caution" as const, content: "The Saturn–Mercury phase from approximately 2019 to 2022 carried heavier mental load because Mercury activated transformation themes under Saturn’s pressure. The Jupiter sub-period from 2022 to 2024 was more favorable, reopening learning, support, and professional confidence." },
    { id: "present", eyebrow: "4 · Present period", title: "The work of the current dasha", tone: "positive" as const, content: "Through October 2027, Jupiter–Saturn asks you to make expansion measurable. Opportunities are strongest when contracts, boundaries, and responsibilities are explicit. Avoid interpreting a slow start as a negative result." },
    { id: "future", eyebrow: "5 · Future phases", title: "Windows ahead", tone: "positive" as const, content: "March 2028 through July 2030 is a stronger visibility window, particularly for leadership, consulting, travel, and teaching. A shorter transition around late 2027 can feel uncertain; keep commitments flexible until the new rhythm becomes clear." },
    { id: "challenges", eyebrow: "6 · Challenges", title: "Name the friction clearly", tone: "caution" as const, content: "Mars influencing the professional axis can produce urgency, while Rahu can magnify opportunities before their foundations are proven. The practical risk is overcommitting, not lack of potential." },
    { id: "remedies", eyebrow: "7 · Remedies", title: "Spiritual and practical support", tone: "neutral" as const, content: "Mantra: recite Om Sham Shanicharaya Namah 108 times on Saturdays for 40 days. Practical action: review one major obligation each week and remove what does not serve the long-term plan. Optional tradition: light a sesame-oil lamp on Saturday evening. These are reflective practices, not guaranteed fixes." },
    { id: "closing", eyebrow: "8 · Closing guidance", title: "Your grounding line", tone: "positive" as const, content: "Choose the path that still makes sense after the excitement has passed." },
    { id: "question", eyebrow: "9 · Your question, answered", title: question || "What should I focus on now?", tone: "neutral" as const, content: "The chart supports focused expansion, but only with visible milestones and firm boundaries. Move forward when the next step is specific; pause when the plan depends mostly on hope or outside pressure." },
  ];
}

function signsForDate(birthDate: string) {
  const month = Number(birthDate.slice(5, 7));
  const signs = ["Capricorn", "Aquarius", "Pisces", "Aries", "Taurus", "Gemini", "Cancer", "Leo", "Virgo", "Libra", "Scorpio", "Sagittarius"];
  return {
    sunSign: signs[(month + 1) % signs.length],
    moonSign: signs[(month + 4) % signs.length],
    ascendant: signs[(month + 7) % signs.length],
  };
}

router.get("/dashboard", async (req, res): Promise<void> => {
  const userId = requireUserId(req);
  if (!userId) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }
  const profiles = await db.select().from(profilesTable).where(eq(profilesTable.userId, userId)).orderBy(profilesTable.createdAt);
  const reports = await db.select().from(reportsTable).where(eq(reportsTable.userId, userId)).orderBy(desc(reportsTable.generatedAt));
  const activeProfile = profiles[0];

  if (!activeProfile) {
    res.status(404).json({ error: "No profile available" });
    return;
  }

  res.json(GetDashboardResponse.parse({
    user: { name: "Aarav", plan: "Explorer", joinedAt: "2026-08-18" },
    activeProfile,
    stats: { reportsReady: reports.length, profiles: profiles.length, insights: 24 },
    featuredInsight: {
      label: "Current Mahadasha",
      title: "A chapter of deliberate expansion",
      body: "Jupiter’s influence rewards patient growth, focused learning, and decisions that build long-term stability rather than quick wins.",
    },
  }));
});

router.get("/activity", async (req, res): Promise<void> => {
  const userId = requireUserId(req);
  if (!userId) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }
  const reports = await db.select().from(reportsTable).where(eq(reportsTable.userId, userId)).orderBy(desc(reportsTable.generatedAt)).limit(3);
  const activities = reports.map((report, index) => ({
    id: `activity-${report.id}`,
    type: "report_ready" as const,
    title: `${report.productName} is ready`,
    description: `A new reading was prepared for ${report.profileName}.`,
    timestamp: report.generatedAt,
    accent: index === 0 ? "violet" as const : index === 1 ? "gold" as const : "teal" as const,
  }));
  res.json(GetActivityResponse.parse(activities));
});

router.get("/profiles", async (req, res): Promise<void> => {
  const userId = requireUserId(req);
  if (!userId) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }
  const profiles = await db.select().from(profilesTable).where(eq(profilesTable.userId, userId)).orderBy(profilesTable.createdAt);
  res.json(ListProfilesResponse.parse(profiles));
});

router.post("/profiles", async (req, res): Promise<void> => {
  const userId = requireUserId(req);
  if (!userId) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }
  const parsed = CreateProfileBody.safeParse(req.body);
  if (!parsed.success) {
    req.log.warn({ errors: parsed.error.message }, "Invalid profile");
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const birthDate = parsed.data.birthDate.toISOString().slice(0, 10);
  const [profile] = await db.insert(profilesTable).values({
    id: randomUUID(),
    userId,
    ...parsed.data,
    birthDate,
    ...signsForDate(birthDate),
    chartStatus: "ready",
  }).returning();
  res.status(201).json(CreateProfileResponse.parse(profile));
});

router.get("/profiles/:profileId", async (req, res): Promise<void> => {
  const userId = requireUserId(req);
  if (!userId) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }
  const params = GetProfileParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [profile] = await db.select().from(profilesTable).where(and(
    eq(profilesTable.id, params.data.profileId),
    eq(profilesTable.userId, userId),
  ));
  if (!profile) {
    res.status(404).json({ error: "Profile not found" });
    return;
  }
  res.json(GetProfileResponse.parse(profile));
});

router.patch("/profiles/:profileId", async (req, res): Promise<void> => {
  const userId = requireUserId(req);
  if (!userId) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }
  const params = GetProfileParams.safeParse(req.params);
  const parsed = UpdateProfileBody.safeParse(req.body);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const birthDate = parsed.data.birthDate.toISOString().slice(0, 10);
  const [profile] = await db
    .update(profilesTable)
    .set({
      ...parsed.data,
      birthDate,
      ...signsForDate(birthDate),
    })
    .where(and(
      eq(profilesTable.id, params.data.profileId),
      eq(profilesTable.userId, userId),
    ))
    .returning();
  if (!profile) {
    res.status(404).json({ error: "Profile not found" });
    return;
  }
  res.json(UpdateProfileResponse.parse(profile));
});

router.delete("/profiles/:profileId", async (req, res): Promise<void> => {
  const userId = requireUserId(req);
  if (!userId) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }
  const params = GetProfileParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [profile] = await db
    .delete(profilesTable)
    .where(and(
      eq(profilesTable.id, params.data.profileId),
      eq(profilesTable.userId, userId),
    ))
    .returning({ id: profilesTable.id });
  if (!profile) {
    res.status(404).json({ error: "Profile not found" });
    return;
  }
  res.status(204).send();
});

router.get("/reports/catalog", (_req, res): void => {
  res.json(ListReportCatalogResponse.parse(reportCatalog));
});

router.get("/reports", async (req, res): Promise<void> => {
  const userId = requireUserId(req);
  if (!userId) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }
  const reports = await db.select().from(reportsTable).where(eq(reportsTable.userId, userId)).orderBy(desc(reportsTable.generatedAt));
  res.json(ListReportsResponse.parse(reports));
});

router.get("/reports/:reportId", async (req, res): Promise<void> => {
  const userId = requireUserId(req);
  if (!userId) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }
  const params = GetReportParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [report] = await db.select().from(reportsTable).where(and(
    eq(reportsTable.id, params.data.reportId),
    eq(reportsTable.userId, userId),
  ));
  if (!report) {
    res.status(404).json({ error: "Report not found" });
    return;
  }
  res.json(GetReportResponse.parse(report));
});

router.post("/reports/generate", async (req, res): Promise<void> => {
  const userId = requireUserId(req);
  if (!userId) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }
  const parsed = GenerateReportBody.safeParse(req.body);
  if (!parsed.success) {
    req.log.warn({ errors: parsed.error.message }, "Invalid report request");
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [profile] = await db.select().from(profilesTable).where(and(
    eq(profilesTable.id, parsed.data.profileId),
    eq(profilesTable.userId, userId),
  ));
  const product = reportCatalog.find((item) => item.id === parsed.data.productId);
  if (!profile || !product) {
    res.status(404).json({ error: "Profile or report product not found" });
    return;
  }
  if (!product.isFree) {
    res.status(402).json({ error: "Payment required for this report" });
    return;
  }
  const [report] = await db.insert(reportsTable).values({
    id: randomUUID(),
    userId,
    profileId: profile.id,
    profileName: profile.name,
    productId: product.id,
    productName: product.name,
    status: "ready",
    question: parsed.data.question,
    summary: `${profile.name}'s chart points toward a season of steady progress, clearer priorities, and grounded decisions. Jupiter’s expansion is moderated by Saturn’s demand for structure, making consistency more valuable than speed.`,
    sections: buildReportSections(profile, parsed.data.question),
    lifeJourney: product.id === "life-journey" ? lifeJourneyFor(profile.birthDate) : [],
    disclaimer,
  }).returning();
  res.status(201).json(GenerateReportResponse.parse(report));
});

export default router;