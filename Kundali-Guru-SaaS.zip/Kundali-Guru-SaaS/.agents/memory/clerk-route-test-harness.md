---
name: Clerk route test harness
description: The undocumented request shape needed to exercise Clerk Express route handlers without live token verification.
---

Direct route tests can use a deterministic auth middleware instead of contacting Clerk, but the request must expose a function branded with `Symbol.for("@clerk/express.auth")` and return `tokenType: "session_token"` alongside `userId`. Router factories are useful for injecting external clients such as Stripe and the admin Clerk client.

**Why:** `getAuth(req)` rejects an unbranded handler, and a generic `"session"` token type is treated as signed out by Clerk's token-type filter.

**How to apply:** Keep this setup confined to integration tests; production routers should continue using Clerk middleware and their default external clients.