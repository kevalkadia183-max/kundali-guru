import { Router, type IRouter } from "express";
import healthRouter from "./health";
import kundaliRouter from "./kundali";
import checkoutRouter from "./checkout";
import adminRouter from "./admin";

const router: IRouter = Router();

router.use(healthRouter);
router.use(kundaliRouter);
router.use(checkoutRouter);
router.use(adminRouter);

export default router;
