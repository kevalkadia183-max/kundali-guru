import { useState, createContext, useContext } from "react"
import type { ToastActionElement, ToastProps } from "@/components/ui/toast"

const TOAST_LIMIT = 1
const TOAST_REMOVE_DELAY = 1000000

type ToasterToast = ToastProps & {
  id: string
  title?: React.ReactNode
  description?: React.ReactNode
  action?: ToastActionElement
}

export const useToast = () => {
  // Stubbed hook for now so that the app compiles and works. 
  // We can add actual toast state management if needed, but for now 
  // it just returns a no-op to satisfy the types and usage.
  return {
    toast: (props: Omit<ToasterToast, "id">) => {
      console.log("Toast:", props);
    },
    dismiss: (toastId?: string) => {},
    toasts: [] as ToasterToast[],
  }
}
