import { getGetReportQueryKey, useGetReport } from "@workspace/api-client-react";
import { useParams, Link } from "wouter";
import { Loader2, ArrowLeft, Download, Share2, Sparkles, BookOpen, AlertCircle, Compass } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, ReferenceLine } from 'recharts';
import { cn } from "@/lib/utils";
import { Card, CardContent } from "@/components/ui/card";

export default function ReportDetail() {
  const { id } = useParams<{ id: string }>();
  const { data: report, isLoading, isError } = useGetReport(id || "", {
    query: { enabled: !!id, queryKey: getGetReportQueryKey(id || "") }
  });

  if (isLoading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] space-y-4">
        <Loader2 className="w-10 h-10 animate-spin text-primary opacity-50" />
        <p className="text-muted-foreground font-serif text-lg">Consulting the ephemeris...</p>
      </div>
    );
  }

  if (isError || !report) {
    return (
      <div className="text-center py-20 flex flex-col items-center justify-center">
        <AlertCircle className="w-12 h-12 text-destructive mb-4" />
        <h2 className="text-3xl font-serif text-foreground">Document Unavailable</h2>
        <p className="text-muted-foreground mt-2 mb-6">This reading could not be located in the archives.</p>
        <Link href="/my-reports">
          <Button variant="outline">Return to Library</Button>
        </Link>
      </div>
    );
  }

  const hasLifeJourney = report.lifeJourney && report.lifeJourney.length > 0;

  return (
    <article className="max-w-4xl mx-auto space-y-16 pb-20 animate-in fade-in duration-700">
      <nav className="flex items-center justify-between sticky top-[64px] bg-background/95 backdrop-blur py-4 z-10 -mx-4 px-4 border-b border-border/50">
        <Link href="/my-reports">
          <Button variant="ghost" className="gap-2 -ml-2 text-muted-foreground hover:text-foreground">
            <ArrowLeft className="w-4 h-4" /> Library
          </Button>
        </Link>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" className="gap-2"><Share2 className="w-4 h-4"/> Share</Button>
          <Button variant="outline" size="sm" className="gap-2"><Download className="w-4 h-4"/> PDF</Button>
        </div>
      </nav>

      <header className="text-center space-y-8 pt-8">
        <div className="space-y-4">
          <Badge variant="outline" className="font-mono uppercase tracking-widest text-[10px] text-accent border-accent/20 bg-accent/5">
            {report.productName}
          </Badge>
          <h1 className="text-4xl md:text-6xl font-serif leading-tight text-foreground">
            Analysis for <br/><span className="text-primary italic">{report.profileName}</span>
          </h1>
        </div>
        
        {report.question && (
          <div className="bg-card border border-border p-6 md:p-8 rounded-2xl inline-block text-left max-w-2xl mx-auto shadow-sm">
            <p className="text-xs font-bold uppercase tracking-wider text-muted-foreground mb-3 flex items-center gap-2">
              <BookOpen className="w-3 h-3" /> Area of Inquiry
            </p>
            <p className="text-xl md:text-2xl font-serif text-foreground leading-relaxed">"{report.question}"</p>
          </div>
        )}
      </header>

      {report.summary && (
        <div className="prose prose-stone dark:prose-invert max-w-none px-4 md:px-0">
          <p className="text-xl md:text-2xl leading-relaxed text-muted-foreground first-letter:text-6xl first-letter:font-serif first-letter:text-primary first-letter:mr-3 first-letter:float-left font-serif">
            {report.summary}
          </p>
        </div>
      )}

      {hasLifeJourney && (
        <section className="space-y-8">
          <div className="text-center space-y-3 mb-10">
            <h2 className="text-3xl font-serif text-foreground flex items-center justify-center gap-3">
              <Compass className="w-6 h-6 text-accent" /> Life Journey Trajectory
            </h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Astrological domains track differently over time. Observe the upcoming peaks and valleys calculated for your specific planetary alignments.
            </p>
          </div>
          
          <Tabs defaultValue={report.lifeJourney[0].id} className="w-full">
            <TabsList className="w-full flex flex-wrap h-auto bg-transparent border-b border-border justify-start rounded-none p-0">
              {report.lifeJourney.map(domain => (
                <TabsTrigger 
                  key={domain.id} 
                  value={domain.id}
                  className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-primary/5 data-[state=active]:shadow-none px-6 py-3 font-serif text-base"
                >
                  {domain.name}
                </TabsTrigger>
              ))}
            </TabsList>
            
            {report.lifeJourney.map(domain => (
              <TabsContent key={domain.id} value={domain.id} className="mt-8 space-y-8 animate-in fade-in slide-in-from-bottom-4">
                <Card className="border-border shadow-sm">
                  <CardContent className="p-6 md:p-8 space-y-8">
                    <p className="text-lg leading-relaxed text-foreground/90 font-serif">
                      {domain.summary}
                    </p>
                    
                    <div className="h-[300px] w-full">
                      <ResponsiveContainer width="100%" height="100%">
                        <AreaChart data={domain.points} margin={{ top: 20, right: 0, left: -20, bottom: 0 }}>
                          <defs>
                            <linearGradient id={`color-${domain.id}`} x1="0" y1="0" x2="0" y2="1">
                              <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.3}/>
                              <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0}/>
                            </linearGradient>
                          </defs>
                          <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="hsl(var(--border))" />
                          <XAxis 
                            dataKey="year" 
                            axisLine={false}
                            tickLine={false}
                            tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 12 }}
                            dy={10}
                          />
                          <YAxis 
                            domain={[-100, 100]} 
                            axisLine={false}
                            tickLine={false}
                            tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 12 }}
                          />
                          <Tooltip 
                            contentStyle={{ 
                              backgroundColor: 'hsl(var(--card))', 
                              borderColor: 'hsl(var(--border))',
                              borderRadius: '0.5rem',
                              fontFamily: 'var(--font-sans)'
                            }}
                            itemStyle={{ color: 'hsl(var(--foreground))' }}
                            labelStyle={{ color: 'hsl(var(--muted-foreground))', marginBottom: '0.25rem' }}
                            formatter={(value: number) => [value > 0 ? `+${value}` : value, 'Favorable Alignment']}
                            labelFormatter={(label) => `Year ${label}`}
                          />
                          <ReferenceLine y={0} stroke="hsl(var(--border))" strokeDasharray="3 3" />
                          <Area 
                            type="monotone" 
                            dataKey="score" 
                            stroke="hsl(var(--primary))" 
                            strokeWidth={2}
                            fillOpacity={1} 
                            fill={`url(#color-${domain.id})`} 
                          />
                        </AreaChart>
                      </ResponsiveContainer>
                    </div>

                    <div className="grid md:grid-cols-2 gap-6 pt-4 border-t border-border">
                      <div className="space-y-2">
                        <h4 className="font-semibold text-sm uppercase tracking-wider text-muted-foreground">Current Period</h4>
                        <p className="text-foreground">{domain.currentPeriod}</p>
                      </div>
                      <div className="space-y-2">
                        <h4 className="font-semibold text-sm uppercase tracking-wider text-muted-foreground">Future Window</h4>
                        <p className="text-foreground">{domain.futureWindow}</p>
                      </div>
                      <div className="space-y-2">
                        <h4 className="font-semibold text-sm uppercase tracking-wider text-accent flex items-center gap-2">
                          <AlertCircle className="w-3 h-3" /> Challenge
                        </h4>
                        <p className="text-foreground leading-relaxed text-sm">{domain.challenge}</p>
                      </div>
                      <div className="space-y-2">
                        <h4 className="font-semibold text-sm uppercase tracking-wider text-green-600 dark:text-green-400 flex items-center gap-2">
                          <Sparkles className="w-3 h-3" /> Recommended Remedy
                        </h4>
                        <p className="text-foreground leading-relaxed text-sm">{domain.remedy}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            ))}
          </Tabs>
        </section>
      )}

      {report.sections && report.sections.length > 0 && (
        <div className="mt-16 space-y-16">
          <div className="relative">
            <div className="absolute inset-0 flex items-center" aria-hidden="true">
              <div className="w-full border-t border-border"></div>
            </div>
            <div className="relative flex justify-center">
              <span className="bg-background px-4 text-sm text-muted-foreground uppercase tracking-widest font-bold">Detailed Analysis</span>
            </div>
          </div>
          
          {report.sections.map((section) => (
            <section key={section.id} className="relative bg-card border border-border p-8 md:p-12 rounded-2xl shadow-sm">
              <div className="mb-8">
                <span className={cn(
                  "text-xs font-bold uppercase tracking-widest block mb-3",
                  section.tone === 'positive' ? "text-green-600 dark:text-green-400" :
                  section.tone === 'caution' ? "text-destructive" :
                  "text-primary"
                )}>
                  {section.eyebrow}
                </span>
                <h2 className="text-3xl font-serif text-foreground m-0">{section.title}</h2>
              </div>
              <div className="text-lg leading-relaxed text-foreground/80 whitespace-pre-wrap font-serif">
                {section.content}
              </div>
            </section>
          ))}
        </div>
      )}
      
      <footer className="pt-16 border-t border-border text-center space-y-6">
        <p className="font-serif italic text-muted-foreground max-w-2xl mx-auto text-sm leading-relaxed">
          {report.disclaimer || "This reading is calculated using traditional Vedic methodology based on the specific parameters provided. It is meant for guidance and perspective, not as absolute decree."}
        </p>
        <p className="text-xs font-mono uppercase tracking-widest text-muted-foreground">Document Authored • {new Date(report.generatedAt).toLocaleDateString()}</p>
        <div className="mt-6 w-12 h-12 rounded-full border border-primary/20 flex items-center justify-center mx-auto text-primary bg-primary/5">
          <Sparkles className="w-5 h-5" />
        </div>
      </footer>
    </article>
  );
}
