import { useUser } from "@clerk/react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { User, Shield, ArrowLeft, BadgeCheck } from "lucide-react";
import { Link } from "wouter";

export default function Account() {
  const { user, isLoaded } = useUser();

  if (!isLoaded) {
    return null;
  }

  const primaryEmail = user?.emailAddresses.find(e => e.id === user.primaryEmailAddressId)?.emailAddress;
  const isAdmin = user?.publicMetadata?.role === "admin";

  return (
    <div className="space-y-8 animate-in fade-in duration-500 max-w-3xl">
      <Link href="/dashboard" className="inline-flex items-center gap-2 text-sm font-medium text-muted-foreground hover:text-foreground">
        <ArrowLeft className="h-4 w-4" /> Back to dashboard
      </Link>
      <div>
        <h1 className="text-3xl font-serif text-foreground">Account</h1>
        <p className="text-muted-foreground mt-2 text-lg">Manage your personal information and security.</p>
      </div>

      <div className="space-y-6">
        <Card className="bg-card border-border">
          <CardHeader>
            <CardTitle className="font-serif text-xl flex items-center gap-2">
              <User className="w-5 h-5 text-primary" /> Profile Information
            </CardTitle>
            <CardDescription>
              Your personal identity across Kundali Guru.
            </CardDescription>
            {isAdmin && (
              <div className="mt-3 inline-flex w-fit items-center gap-2 rounded-full bg-primary/10 px-3 py-1 text-xs font-semibold uppercase tracking-wide text-primary">
                <BadgeCheck className="h-4 w-4" /> Administrator
              </div>
            )}
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>First Name</Label>
                <Input value={user?.firstName || ""} readOnly className="bg-muted/50" />
              </div>
              <div className="space-y-2">
                <Label>Last Name</Label>
                <Input value={user?.lastName || ""} readOnly className="bg-muted/50" />
              </div>
            </div>
            <div className="space-y-2">
              <Label>Primary Email</Label>
              <div className="flex gap-2">
                <Input value={primaryEmail || ""} readOnly className="bg-muted/50" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardHeader>
            <CardTitle className="font-serif text-xl flex items-center gap-2">
              <Shield className="w-5 h-5 text-primary" /> Security
            </CardTitle>
            <CardDescription>
              Authentication and login methods.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="flex items-center justify-between py-2 border-b border-border/50">
              <div className="space-y-1">
                <p className="font-medium">Password</p>
                <p className="text-sm text-muted-foreground">Sign in with an email and password.</p>
              </div>
              <Button variant="outline" size="sm">Update</Button>
            </div>
            <div className="flex items-center justify-between py-2">
              <div className="space-y-1">
                <p className="font-medium">Connected Accounts</p>
                <p className="text-sm text-muted-foreground">Sign in with Google, Apple, etc.</p>
              </div>
              <Button variant="outline" size="sm">Manage</Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
