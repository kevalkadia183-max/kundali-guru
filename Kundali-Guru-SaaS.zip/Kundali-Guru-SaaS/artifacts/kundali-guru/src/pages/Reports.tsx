import { useListReportCatalog, useListProfiles, useGenerateReport, getListReportsQueryKey, useCreateCheckout, useCompleteCheckout, getCompleteCheckoutQueryKey } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Loader2, Sparkles, Clock, CheckCircle } from "lucide-react";
import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { useQueryClient } from "@tanstack/react-query";

export default function Reports() {
  const { data: catalog, isLoading: loadingCatalog } = useListReportCatalog();
  const [, setLocation] = useLocation();
  const sessionId = new URLSearchParams(window.location.search).get("session_id") ?? "";
  const checkoutStatus = useCompleteCheckout(sessionId, {
    query: {
      queryKey: getCompleteCheckoutQueryKey(sessionId),
      enabled: Boolean(sessionId),
      retry: 2,
    },
  });

  useEffect(() => {
    if (checkoutStatus.data?.status !== "paid") return;
    const ids = checkoutStatus.data.reportIds;
    setLocation(ids.length === 1 ? `/reports/${ids[0]}` : "/my-reports");
  }, [checkoutStatus.data, setLocation]);
  
  const singleReports = catalog?.filter(p => !p.isBundle) || [];
  const bundleReport = catalog?.find(p => p.isBundle);
  
  return (
    <div className="space-y-12 animate-in fade-in duration-500 pb-12">
      {sessionId && (
        <div className="rounded-xl border border-accent/30 bg-accent/10 px-5 py-4 text-sm">
          {checkoutStatus.isLoading
            ? "Verifying your secure payment and preparing your report…"
            : checkoutStatus.data?.status === "pending"
              ? "Payment confirmation is still pending. This page will retry automatically."
              : "Payment verified. Opening your report library…"}
        </div>
      )}
      <div>
        <h1 className="text-3xl font-serif text-foreground">Reading Room</h1>
        <p className="text-muted-foreground mt-2 text-lg max-w-2xl">
          Select a domain of inquiry. Our Vedic system will analyze planetary positions to deliver precise, scholarly insight.
        </p>
      </div>

      {loadingCatalog ? (
        <div className="flex items-center justify-center py-20"><Loader2 className="w-8 h-8 animate-spin text-primary opacity-50" /></div>
      ) : (
        <>
          {/* Bundle Banner */}
          {bundleReport && (
            <section className="relative overflow-hidden rounded-2xl bg-primary text-primary-foreground shadow-lg border border-primary/20 p-8 md:p-10">
              <div className="absolute right-0 top-0 w-[400px] h-[400px] bg-accent/20 rounded-full blur-3xl -mr-20 -mt-20 pointer-events-none" />
              <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-8">
                <div className="space-y-4 max-w-xl">
                  <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-accent/20 text-accent font-medium text-xs uppercase tracking-widest border border-accent/20">
                    <Sparkles className="w-3 h-3" /> Complete Analysis
                  </div>
                  <h2 className="text-3xl md:text-4xl font-serif">{bundleReport.name}</h2>
                  <p className="text-primary-foreground/80 text-lg leading-relaxed">
                    {bundleReport.description}
                  </p>
                  <ul className="grid grid-cols-1 sm:grid-cols-2 gap-3 mt-4">
                    <li className="flex items-center gap-2 text-primary-foreground/90"><CheckCircle className="w-4 h-4 text-accent" /> All 10 domain reports</li>
                    <li className="flex items-center gap-2 text-primary-foreground/90"><CheckCircle className="w-4 h-4 text-accent" /> Life journey timeline</li>
                    <li className="flex items-center gap-2 text-primary-foreground/90"><CheckCircle className="w-4 h-4 text-accent" /> Permanent library access</li>
                  </ul>
                </div>
                <div className="bg-background/10 backdrop-blur-md border border-white/10 rounded-xl p-6 text-center shrink-0 w-full md:w-72 shadow-2xl">
                  <div className="text-sm font-medium text-accent uppercase tracking-wider mb-2">Bundle Pricing</div>
                  <div className="flex items-end justify-center gap-3 mb-1">
                    <span className="text-4xl font-serif font-medium">₹799</span>
                    <span className="text-lg text-primary-foreground/50 line-through mb-1">₹891</span>
                  </div>
                  <div className="text-accent font-medium text-sm mb-6">Save ₹92</div>
                  <BundleCheckout product={bundleReport} />
                </div>
              </div>
            </section>
          )}

          <div className="space-y-6">
            <h3 className="text-2xl font-serif text-foreground">Individual Readings</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {singleReports.map(product => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          </div>
        </>
      )}
    </div>
  );
}

function ProductCard({ product }: { product: any }) {
  const [open, setOpen] = useState(false);
  const { data: profiles } = useListProfiles();
  const generateReport = useGenerateReport();
  const checkout = useCreateCheckout();
  const queryClient = useQueryClient();
  const [, setLocation] = useLocation();
  
  const [profileId, setProfileId] = useState<string>("");
  const [question, setQuestion] = useState("");
  
  const isPaid = !product.isFree;

  const handleGenerate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!profileId) return;
    
    if (isPaid) {
      checkout.mutate({
        data: { profileId, productId: product.id, question },
      }, {
        onSuccess: ({ url }) => window.location.assign(url),
      });
      return;
    }

    generateReport.mutate({
      data: {
        profileId,
        productId: product.id,
        question: isPaid ? question : "",
        quickAnswers: []
      }
    }, {
      onSuccess: (data) => {
        queryClient.invalidateQueries({ queryKey: getListReportsQueryKey() });
        setOpen(false);
        setLocation(`/reports/${data.id}`);
      }
    });
  };

  return (
    <Card className={`relative overflow-hidden flex flex-col h-full ${product.isFeatured ? 'border-primary shadow-md' : 'border-border'}`}>
      {product.isFeatured && (
        <div className="absolute top-0 right-0 bg-primary text-primary-foreground text-[10px] uppercase font-bold px-3 py-1 rounded-bl-lg z-10 flex items-center gap-1">
          <Sparkles className="w-3 h-3" /> Featured
        </div>
      )}
      <CardHeader>
        <div className="text-xs font-medium text-accent uppercase tracking-wider mb-2">
          {product.category}
        </div>
        <CardTitle className="font-serif text-xl">{product.name}</CardTitle>
        <CardDescription className="line-clamp-3 mt-2 text-sm leading-relaxed text-muted-foreground">
          {product.description}
        </CardDescription>
      </CardHeader>
      <CardContent className="mt-auto">
        <div className="flex items-center justify-between text-sm mt-4">
          <div className="flex items-center gap-1 text-muted-foreground">
            <Clock className="w-4 h-4" /> {product.duration}
          </div>
          <div className="font-medium text-foreground text-lg font-serif">
            {product.isFree ? "Free" : `₹${product.price}`}
          </div>
        </div>
      </CardContent>
      <CardFooter className="pt-0">
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button className="w-full" variant={product.isFeatured ? "default" : "outline"}>
              {product.isFree ? "Generate Free Report" : "Request Reading"}
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[425px]">
            <form onSubmit={handleGenerate}>
              <DialogHeader>
                <DialogTitle className="font-serif text-2xl">{product.name}</DialogTitle>
                <DialogDescription>
                  Select the subject profile for this reading.
                </DialogDescription>
              </DialogHeader>
              <div className="py-6 space-y-6">
                <div className="space-y-3">
                  <Label>Subject Profile</Label>
                  <Select value={profileId} onValueChange={setProfileId}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select a profile..." />
                    </SelectTrigger>
                    <SelectContent>
                      {profiles?.map(p => (
                        <SelectItem key={p.id} value={p.id}>{p.name} ({p.relationship})</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                {isPaid && (
                  <div className="space-y-3">
                    <Label className="flex justify-between">
                      <span>Specific Focus (Optional)</span>
                      <span className="text-muted-foreground font-normal text-xs">Included with paid reading</span>
                    </Label>
                    <Textarea 
                      placeholder="e.g. Will my career transition this year be successful?"
                      value={question}
                      onChange={e => setQuestion(e.target.value)}
                      className="resize-none h-24"
                    />
                  </div>
                )}
              </div>
              <DialogFooter>
                <Button type="submit" disabled={!profileId || generateReport.isPending || checkout.isPending} className="w-full sm:w-auto">
                  {(generateReport.isPending || checkout.isPending) && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
                  {isPaid ? `Proceed to Payment (₹${product.price})` : "Generate Analysis"}
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </CardFooter>
    </Card>
  );
}

function BundleCheckout({ product }: { product: any }) {
  const [open, setOpen] = useState(false);
  const [profileId, setProfileId] = useState("");
  const { data: profiles } = useListProfiles();
  const checkout = useCreateCheckout();

  const handleCheckout = () => {
    if (!profileId) return;
    checkout.mutate({
      data: { productId: product.id, profileId, question: "" },
    }, {
      onSuccess: ({ url }) => window.location.assign(url),
    });
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button size="lg" className="w-full bg-white text-primary hover:bg-white/90 font-medium">
          Acquire Bundle
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle className="font-serif text-2xl">Acquire Full Bundle</DialogTitle>
          <DialogDescription>
            Unlock all 10 domain reports and permanent life journey access.
          </DialogDescription>
        </DialogHeader>
        <div className="py-8 flex flex-col items-center justify-center text-center space-y-4">
          <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center text-primary mb-2">
            <Sparkles className="w-8 h-8" />
          </div>
           <p className="text-muted-foreground max-w-sm">
             Select one birth profile. Stripe will securely process the one-time payment and all nine premium reports will be prepared for that profile.
           </p>
           <Select value={profileId} onValueChange={setProfileId}>
             <SelectTrigger className="w-full">
               <SelectValue placeholder="Select a profile…" />
             </SelectTrigger>
             <SelectContent>
               {profiles?.map((profile) => (
                 <SelectItem key={profile.id} value={profile.id}>
                   {profile.name} ({profile.relationship})
                 </SelectItem>
               ))}
             </SelectContent>
           </Select>
        </div>
        <DialogFooter>
           <Button onClick={handleCheckout} disabled={!profileId || checkout.isPending} className="w-full">
             {checkout.isPending && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
             Continue to secure checkout (₹799)
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
