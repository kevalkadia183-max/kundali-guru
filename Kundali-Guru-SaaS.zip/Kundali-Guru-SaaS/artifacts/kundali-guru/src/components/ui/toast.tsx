import * as React from "react"

export interface ToastProps extends React.HTMLAttributes<HTMLDivElement> {
  variant?: "default" | "destructive"
}
export type ToastActionElement = React.ReactElement

export function Toaster() {
  return null;
}
