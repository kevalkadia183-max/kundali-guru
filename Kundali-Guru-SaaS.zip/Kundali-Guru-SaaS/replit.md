# Kundali Guru

A premium Vedic astrology SaaS for creating birth profiles, generating guided reports, and revisiting personalized insights.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `artifacts/kundali-guru` — customer-facing React application
- `artifacts/api-server/src/routes/kundali.ts` — dashboard, profile, and report APIs
- `lib/api-spec/openapi.yaml` — source of truth for API contracts
- `lib/db/src/schema` — profile and report persistence
- `artifacts/kundali-guru/src/index.css` — product theme and visual tokens

## Architecture decisions

- Deterministic chart calculations and AI interpretation are kept as separate layers.
- Generated reports are stored as snapshots so users can revisit the exact purchased output.
- The first product slice uses a single demo workspace while managed authentication is added as a separate production step.

## Product

- Dashboard with active profile context, report metrics, featured insight, and recent activity
- Multiple saved birth profiles with chart-ready status
- Free and paid report catalog with generation questions
- Persistent report history and long-form reading experience
- Settings for language, privacy, ayanamsha, and chart preferences

## User preferences

_Populate as you build — explicit user instructions worth remembering across sessions._

## Gotchas

_Populate as you build — sharp edges, "always run X before Y" rules._

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
