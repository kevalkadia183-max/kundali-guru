import { useGetAdminOverview } from "@workspace/api-client-react";
import { BadgeCheck, BookOpen, CreditCard, IndianRupee, Loader2, UserRound, Users } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

const money = new Intl.NumberFormat("en-IN", {
  style: "currency",
  currency: "INR",
  maximumFractionDigits: 0,
});

export default function Admin() {
  const { data, isLoading, error } = useGetAdminOverview();

  if (isLoading) {
    return (
      <div className="flex min-h-[60vh] items-center justify-center">
        <Loader2 className="h-9 w-9 animate-spin text-primary" />
      </div>
    );
  }

  if (error || !data) {
    return (
      <Card className="mx-auto mt-12 max-w-xl">
        <CardContent className="p-8 text-center">
          <h1 className="font-serif text-2xl">Administrator access required</h1>
          <p className="mt-2 text-muted-foreground">This business dashboard is available only to authorized administrators.</p>
        </CardContent>
      </Card>
    );
  }

  const stats = [
    { label: "Total users", value: data.stats.users, icon: Users },
    { label: "Birth profiles", value: data.stats.profiles, icon: UserRound },
    { label: "Reports generated", value: data.stats.reports, icon: BookOpen },
    { label: "Paid reports", value: data.stats.paidOrders, icon: CreditCard },
    { label: "Total income", value: money.format(data.stats.paidRevenueInr), icon: IndianRupee },
  ];

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div>
        <div className="flex items-center gap-2 text-sm font-semibold uppercase tracking-[0.18em] text-primary">
          <BadgeCheck className="h-4 w-4" /> Administrator
        </div>
        <h1 className="mt-2 font-serif text-3xl text-foreground">Business overview</h1>
        <p className="mt-2 text-muted-foreground">Users, report activity, payments, and recent platform operations.</p>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-5">
        {stats.map(({ label, value, icon: Icon }) => (
          <Card key={label}>
            <CardContent className="p-5">
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">{label}</span>
                <Icon className="h-4 w-4 text-primary" />
              </div>
              <p className="mt-3 font-serif text-2xl font-semibold">{value}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card>
        <CardHeader><CardTitle className="font-serif">All users</CardTitle></CardHeader>
        <CardContent className="overflow-x-auto">
          <table className="w-full min-w-[760px] text-sm">
            <thead><tr className="border-b text-left text-muted-foreground"><th className="pb-3 font-medium">User</th><th className="pb-3 font-medium">Role</th><th className="pb-3 font-medium">Joined</th><th className="pb-3 text-right font-medium">Reports purchased</th><th className="pb-3 text-right font-medium">Spent</th></tr></thead>
            <tbody>
              {data.users.map((user) => (
                <tr key={user.id} className="border-b border-border/60 last:border-0">
                  <td className="py-4"><div className="font-medium">{user.name}</div><div className="text-muted-foreground">{user.email}</div></td>
                  <td className="py-4"><span className="rounded-full bg-muted px-2.5 py-1 text-xs font-semibold">{user.role}</span></td>
                  <td className="py-4 text-muted-foreground">{new Date(user.joinedAt).toLocaleDateString("en-IN")}</td>
                  <td className="py-4 text-right">{user.reportsPurchased}</td>
                  <td className="py-4 text-right font-medium">{money.format(user.amountSpentInr)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </CardContent>
      </Card>

      <div className="grid gap-6 xl:grid-cols-2">
        <Card>
          <CardHeader><CardTitle className="font-serif">Recent payments</CardTitle></CardHeader>
          <CardContent className="space-y-1">
            {data.recentOrders.map((order) => (
              <div key={order.id} className="flex items-center justify-between gap-4 border-b py-3 last:border-0">
                <div className="min-w-0"><p className="truncate font-medium">{order.productName}</p><p className="truncate text-xs text-muted-foreground">{order.userEmail} · {new Date(order.createdAt).toLocaleDateString("en-IN")}</p></div>
                <div className="text-right"><p className="font-semibold">{money.format(order.amountInr)}</p><p className="text-xs capitalize text-muted-foreground">{order.status}</p></div>
              </div>
            ))}
            {!data.recentOrders.length && <p className="py-8 text-center text-sm text-muted-foreground">No payments yet.</p>}
          </CardContent>
        </Card>
        <Card>
          <CardHeader><CardTitle className="font-serif">Recent reports</CardTitle></CardHeader>
          <CardContent className="space-y-1">
            {data.recentReports.map((report) => (
              <div key={report.id} className="flex items-center justify-between gap-4 border-b py-3 last:border-0">
                <div className="min-w-0"><p className="truncate font-medium">{report.productName}</p><p className="truncate text-xs text-muted-foreground">{report.profileName}</p></div>
                <div className="text-right"><p className="text-sm">{new Date(report.generatedAt).toLocaleDateString("en-IN")}</p><p className="text-xs capitalize text-muted-foreground">{report.status}</p></div>
              </div>
            ))}
            {!data.recentReports.length && <p className="py-8 text-center text-sm text-muted-foreground">No reports generated yet.</p>}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}