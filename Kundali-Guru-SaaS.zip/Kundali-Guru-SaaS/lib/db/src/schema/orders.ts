import { integer, pgTable, text, timestamp } from "drizzle-orm/pg-core";

export const ordersTable = pgTable("orders", {
  id: text("id").primaryKey(),
  userId: text("user_id").notNull(),
  profileId: text("profile_id").notNull(),
  productId: text("product_id").notNull(),
  stripeSessionId: text("stripe_session_id").notNull(),
  amount: integer("amount").notNull(),
  currency: text("currency").notNull().default("inr"),
  status: text("status").notNull().default("paid"),
  question: text("question").notNull().default(""),
  reportId: text("report_id"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export type Order = typeof ordersTable.$inferSelect;