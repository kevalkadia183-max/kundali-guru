---
name: Stripe sync bundling
description: Why Stripe's synchronization library must remain external in bundled API servers.
---

Keep `stripe-replit-sync` external to the API server's esbuild bundle.

**Why:** The library locates SQL migrations relative to its installed package directory. Bundling rewrites that directory to the server output folder, so migrations appear to finish but create no Stripe tables.

**How to apply:** Whenever changing the API build pipeline or Stripe sync version, confirm the package remains external and that startup can query the managed Stripe schema after migrations.