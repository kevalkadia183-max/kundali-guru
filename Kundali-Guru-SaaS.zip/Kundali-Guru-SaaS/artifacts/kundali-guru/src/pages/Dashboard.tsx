import { useGetDashboard, useGetActivity } from "@workspace/api-client-react";
import { Link } from "wouter";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Loader2, Sparkles, Plus, BookOpen, Clock, ChevronRight, User } from "lucide-react";

export default function Dashboard() {
  const { data: dashboard, isLoading: dashLoading } = useGetDashboard();
  const { data: activity, isLoading: actLoading } = useGetActivity();

  if (dashLoading || actLoading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] space-y-4">
        <Loader2 className="w-10 h-10 animate-spin text-primary opacity-50" />
        <p className="text-muted-foreground font-serif text-lg">Aligning the charts...</p>
      </div>
    );
  }

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div>
        <h1 className="text-3xl font-serif text-foreground">Welcome back, {dashboard?.user.name}</h1>
        <p className="text-muted-foreground mt-1 text-lg">The stars are aligned for insight today.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="bg-primary text-primary-foreground border-none">
          <CardHeader>
            <CardTitle className="font-serif text-2xl font-normal">Active Profile</CardTitle>
          </CardHeader>
          <CardContent>
            {dashboard?.activeProfile ? (
              <div className="space-y-4">
                <div>
                  <p className="font-semibold text-lg">{dashboard.activeProfile.name}</p>
                  <p className="text-primary-foreground/70 text-sm">Sun in {dashboard.activeProfile.sunSign} • Moon in {dashboard.activeProfile.moonSign}</p>
                </div>
                <Link href="/profiles">
                  <Button variant="secondary" className="w-full text-foreground bg-white hover:bg-white/90">Switch Profile</Button>
                </Link>
              </div>
            ) : (
              <div className="space-y-4">
                <p className="text-primary-foreground/70">No active profile selected.</p>
                <Link href="/profiles">
                  <Button variant="secondary" className="w-full text-foreground bg-white hover:bg-white/90">
                    <Plus className="w-4 h-4 mr-2" /> Add Profile
                  </Button>
                </Link>
              </div>
            )}
          </CardContent>
        </Card>

        <Card className="col-span-1 md:col-span-2 relative overflow-hidden bg-card/50 backdrop-blur">
          <div className="absolute right-0 top-0 w-32 h-32 bg-accent/10 rounded-full blur-2xl -mr-10 -mt-10" />
          <CardHeader>
            <CardTitle className="font-serif text-xl flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-accent" />
              Daily Insight
            </CardTitle>
          </CardHeader>
          <CardContent>
            <h3 className="text-lg font-medium text-foreground mb-2">{dashboard?.featuredInsight.title}</h3>
            <p className="text-muted-foreground leading-relaxed">
              {dashboard?.featuredInsight.body}
            </p>
            <div className="mt-6 flex justify-end">
              <Link href="/reports">
                <Button variant="link" className="text-primary group px-0">
                  Enter Reading Room <ChevronRight className="ml-1 w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-serif text-foreground">Recent Activity</h2>
          </div>
          <div className="space-y-4">
            {activity?.slice(0, 5).map((item) => (
              <div key={item.id} className="flex items-start gap-4 p-4 rounded-xl bg-card border border-border">
                <div className={`w-10 h-10 rounded-full flex items-center justify-center shrink-0 ${
                  item.type === 'report_ready' ? 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400' :
                  item.type === 'profile_created' ? 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400' :
                  'bg-accent/20 text-accent-foreground'
                }`}>
                  {item.type === 'report_ready' ? <BookOpen className="w-5 h-5" /> :
                   item.type === 'profile_created' ? <User className="w-5 h-5" /> :
                   <Sparkles className="w-5 h-5" />}
                </div>
                <div className="flex-1 min-w-0">
                  <h4 className="text-sm font-medium text-foreground truncate">{item.title}</h4>
                  <p className="text-sm text-muted-foreground line-clamp-1">{item.description}</p>
                </div>
                <div className="text-xs text-muted-foreground whitespace-nowrap pt-1 flex items-center gap-1">
                  <Clock className="w-3 h-3" />
                  {new Date(item.timestamp).toLocaleDateString()}
                </div>
              </div>
            ))}
            {activity?.length === 0 && (
              <div className="text-center py-10 bg-muted/20 border border-dashed rounded-xl">
                <p className="text-muted-foreground text-sm">No recent activity.</p>
              </div>
            )}
          </div>
        </div>
        
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-serif text-foreground">Quick Actions</h2>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <Link href="/reports">
              <Card className="hover:border-primary/50 transition-colors cursor-pointer h-full">
                <CardContent className="p-6 flex flex-col items-center justify-center text-center space-y-3">
                  <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center text-primary">
                    <BookOpen className="w-6 h-6" />
                  </div>
                  <span className="font-medium text-foreground">Request Reading</span>
                </CardContent>
              </Card>
            </Link>
            <Link href="/profiles">
              <Card className="hover:border-primary/50 transition-colors cursor-pointer h-full">
                <CardContent className="p-6 flex flex-col items-center justify-center text-center space-y-3">
                  <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center text-primary">
                    <Plus className="w-6 h-6" />
                  </div>
                  <span className="font-medium text-foreground">Add Profile</span>
                </CardContent>
              </Card>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
