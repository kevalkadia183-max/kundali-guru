import { useEffect, useRef } from "react";
import { ClerkProvider, SignIn, SignUp, Show, useClerk } from '@clerk/react';
import { publishableKeyFromHost } from '@clerk/react/internal';
import { shadcn } from '@clerk/themes'; 
import { Switch, Route, useLocation, Router as WouterRouter, Redirect } from 'wouter';
import { QueryClient, QueryClientProvider, useQueryClient } from "@tanstack/react-query";

import { ShellLayout, PublicLayout } from '@/components/layout/ShellLayout';
import Landing from '@/pages/Landing';
import Dashboard from '@/pages/Dashboard';
import Profiles from '@/pages/Profiles';
import Reports from '@/pages/Reports';
import MyReports from '@/pages/MyReports';
import ReportDetail from '@/pages/ReportDetail';
import Settings from '@/pages/Settings';
import Account from '@/pages/Account';
import Admin from '@/pages/Admin';
import Privacy from '@/pages/Privacy';
import Terms from '@/pages/Terms';

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: false,
      refetchOnWindowFocus: false,
    },
  },
});

const clerkPubKey = publishableKeyFromHost(
  window.location.hostname,
  import.meta.env.VITE_CLERK_PUBLISHABLE_KEY,
);

const clerkProxyUrl = import.meta.env.VITE_CLERK_PROXY_URL;
const basePath = import.meta.env.BASE_URL?.replace(/\/$/, "") || "";

function stripBase(path: string): string {
  return basePath && path.startsWith(basePath)
    ? path.slice(basePath.length) || "/"
    : path;
}

if (!clerkPubKey) {
  throw new Error('Missing VITE_CLERK_PUBLISHABLE_KEY in .env file');
}

const clerkAppearance = {
  theme: shadcn,
  cssLayerName: "clerk",
  options: {
    logoPlacement: "inside" as const,
    logoLinkUrl: basePath || "/",
    logoImageUrl: `${window.location.origin}${basePath}/logo.svg`,
  },
  variables: {
    colorPrimary: "hsl(232 50% 20%)",
    colorForeground: "hsl(232 30% 15%)",       
    colorMutedForeground: "hsl(232 10% 40%)",  
    colorDanger: "hsl(0 60% 50%)",
    colorBackground: "hsl(40 33% 99%)",       
    colorInput: "hsl(40 20% 85%)",            
    colorInputForeground: "hsl(232 30% 15%)",  
    colorNeutral: "hsl(40 20% 85%)",          
    fontFamily: "'Outfit', sans-serif",
    borderRadius: "0.5rem",
  },
  elements: {
    rootBox: "w-full flex justify-center",
    cardBox: "bg-card rounded-2xl w-[440px] max-w-full overflow-hidden shadow-sm border border-border",
    card: "!shadow-none !border-0 !bg-transparent !rounded-none",
    footer: "!shadow-none !border-0 !bg-transparent !rounded-none",
    headerTitle: "text-foreground font-serif text-2xl font-semibold",
    headerSubtitle: "text-muted-foreground",
    socialButtonsBlockButtonText: "text-foreground font-medium",
    formFieldLabel: "text-foreground font-medium",
    footerActionLink: "text-primary hover:text-primary/90 font-medium",
    footerActionText: "text-muted-foreground",
    dividerText: "text-muted-foreground",
    identityPreviewEditButton: "text-primary hover:text-primary/90",
    formFieldSuccessText: "text-green-600",
    alertText: "text-destructive",
    logoBox: "h-12 w-auto mx-auto mb-6",
    logoImage: "h-full w-auto object-contain",
    socialButtonsBlockButton: "border-border hover:bg-muted/50",
    formButtonPrimary: "bg-primary hover:bg-primary/90 text-primary-foreground",
    formFieldInput: "bg-background border-input text-foreground focus:ring-ring focus:border-ring",
    footerAction: "mt-6",
    dividerLine: "bg-border",
    alert: "bg-destructive/10 border-destructive/20",
    otpCodeFieldInput: "bg-background border-input text-foreground",
    formFieldRow: "gap-4",
    main: "space-y-4",
  },
};

function SignInPage() {
  return (
    <PublicLayout>
      <div className="flex min-h-[80vh] items-center justify-center py-12 px-4">
        <SignIn routing="path" path={`${basePath}/sign-in`} signUpUrl={`${basePath}/sign-up`} />
      </div>
    </PublicLayout>
  );
}

function SignUpPage() {
  return (
    <PublicLayout>
      <div className="flex min-h-[80vh] items-center justify-center py-12 px-4">
        <SignUp routing="path" path={`${basePath}/sign-up`} signInUrl={`${basePath}/sign-in`} />
      </div>
    </PublicLayout>
  );
}

function ClerkQueryClientCacheInvalidator() {
  const { addListener } = useClerk();
  const queryClientLocal = useQueryClient();
  const prevUserIdRef = useRef<string | null | undefined>(undefined);

  useEffect(() => {
    const unsubscribe = addListener(({ user }) => {
      const userId = user?.id ?? null;
      if (
        prevUserIdRef.current !== undefined &&
        prevUserIdRef.current !== userId
      ) {
        queryClientLocal.clear();
      }
      prevUserIdRef.current = userId;
    });
    return unsubscribe;
  }, [addListener, queryClientLocal]);

  return null;
}

function HomeRedirect() {
  return (
    <>
      <Show when="signed-in">
        <Redirect to="/dashboard" />
      </Show>
      <Show when="signed-out">
        <PublicLayout>
          <Landing />
        </PublicLayout>
      </Show>
    </>
  );
}

function ProtectedRoute({ component: Component, ...rest }: { component: React.ComponentType<any>, path: string }) {
  return (
    <Route {...rest}>
      {(params) => (
        <>
          <Show when="signed-in">
            <ShellLayout>
              <Component {...params} />
            </ShellLayout>
          </Show>
          <Show when="signed-out">
            <Redirect to="/sign-in" />
          </Show>
        </>
      )}
    </Route>
  );
}

function PublicRoute({ component: Component, ...rest }: { component: React.ComponentType<any>, path: string }) {
  return (
    <Route {...rest}>
      {(params) => (
        <PublicLayout>
          <Component {...params} />
        </PublicLayout>
      )}
    </Route>
  );
}

function NotFound() {
  return (
    <div className="flex flex-col items-center justify-center min-h-[60vh] space-y-4">
      <h2 className="text-4xl font-serif text-foreground">Lost in the Cosmos</h2>
      <p className="text-muted-foreground text-lg text-center max-w-md">
        The page you are looking for does not exist in our current alignment.
      </p>
    </div>
  );
}

function ClerkProviderWithRoutes() {
  const [, setLocation] = useLocation();

  return (
    <ClerkProvider
      publishableKey={clerkPubKey}
      proxyUrl={clerkProxyUrl}
      appearance={clerkAppearance}
      signInUrl={`${basePath}/sign-in`}
      signUpUrl={`${basePath}/sign-up`}
      localization={{
        signIn: { start: { title: "Welcome back", subtitle: "Enter the reading room" } },
        signUp: { start: { title: "Create your profile", subtitle: "Begin your celestial journey" } },
      }}
      routerPush={(to) => setLocation(stripBase(to))}
      routerReplace={(to) => setLocation(stripBase(to), { replace: true })}
    >
      <QueryClientProvider client={queryClient}>
        <ClerkQueryClientCacheInvalidator />
        <Switch>
          <Route path="/" component={HomeRedirect} />
          <Route path="/sign-in/*?" component={SignInPage} />
          <Route path="/sign-up/*?" component={SignUpPage} />
          
          <PublicRoute path="/privacy" component={Privacy} />
          <PublicRoute path="/terms" component={Terms} />

          <ProtectedRoute path="/dashboard" component={Dashboard} />
          <ProtectedRoute path="/profiles" component={Profiles} />
          <ProtectedRoute path="/reports" component={Reports} />
          <ProtectedRoute path="/my-reports" component={MyReports} />
          <ProtectedRoute path="/reports/:id" component={ReportDetail} />
          <ProtectedRoute path="/account" component={Account} />
          <ProtectedRoute path="/admin" component={Admin} />
          <ProtectedRoute path="/settings" component={Settings} />
          
          <Route>
            <ShellLayout>
              <NotFound />
            </ShellLayout>
          </Route>
        </Switch>
      </QueryClientProvider>
    </ClerkProvider>
  );
}

function App() {
  return (
    <WouterRouter base={basePath}>
      <ClerkProviderWithRoutes />
    </WouterRouter>
  );
}

export default App;
