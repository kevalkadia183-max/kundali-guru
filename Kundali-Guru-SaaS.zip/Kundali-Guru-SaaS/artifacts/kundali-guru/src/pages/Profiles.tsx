import { useListProfiles, useCreateProfile, useUpdateProfile, useDeleteProfile, getListProfilesQueryKey, type Profile } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Switch } from "@/components/ui/switch";
import { Loader2, Plus, User, MapPin, Calendar, Clock, Trash2, ArrowLeft, Pencil } from "lucide-react";
import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { Link } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";

const profileSchema = z.object({
  name: z.string().min(2, "Name must be at least 2 characters"),
  relationship: z.string().min(2, "Relationship is required"),
  birthDate: z.string().min(1, "Birth date is required"),
  birthTime: z.string().min(1, "Birth time is required"),
  birthPlace: z.string().min(1, "Birth place is required"),
  timezone: z.string().min(1, "Timezone is required"),
  isApproximateTime: z.boolean().default(false),
});

type ProfileFormValues = z.infer<typeof profileSchema>;

export default function Profiles() {
  const { data: profiles, isLoading } = useListProfiles();
  
  return (
    <div className="space-y-8 animate-in fade-in duration-500 pb-12">
      <Link href="/dashboard" className="inline-flex items-center gap-2 text-sm font-medium text-muted-foreground hover:text-foreground">
        <ArrowLeft className="h-4 w-4" /> Back to dashboard
      </Link>
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-serif text-foreground">Saved Profiles</h1>
          <p className="text-muted-foreground mt-2 text-lg">Manage birth details for yourself and your loved ones.</p>
        </div>
         <ProfileDialog />
      </div>

      {isLoading ? (
        <div className="flex items-center justify-center py-20"><Loader2 className="w-8 h-8 animate-spin text-primary opacity-50" /></div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {profiles?.map(profile => (
            <Card key={profile.id} className="overflow-hidden border-border hover:border-primary/50 transition-colors bg-card">
              <CardHeader className="pb-4 bg-muted/30 border-b border-border">
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle className="font-serif text-xl">{profile.name}</CardTitle>
                    <CardDescription className="uppercase tracking-wider text-[10px] font-bold mt-1 text-primary">{profile.relationship}</CardDescription>
                  </div>
                  <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center text-primary shrink-0">
                    <User className="w-5 h-5" />
                  </div>
                </div>
              </CardHeader>
              <CardContent className="pt-6 space-y-4">
                <div className="grid grid-cols-2 gap-y-4 gap-x-2 text-sm">
                  <div className="space-y-1">
                    <div className="flex items-center gap-1.5 text-muted-foreground">
                      <Calendar className="w-3.5 h-3.5" /> Date
                    </div>
                    <div className="font-medium text-foreground">{formatBirthDate(profile.birthDate)}</div>
                  </div>
                  <div className="space-y-1">
                    <div className="flex items-center gap-1.5 text-muted-foreground">
                      <Clock className="w-3.5 h-3.5" /> Time
                    </div>
                    <div className="font-medium text-foreground">
                      {profile.birthTime} 
                      {profile.isApproximateTime && <span className="text-muted-foreground font-normal ml-1">(Approx)</span>}
                    </div>
                  </div>
                  <div className="space-y-1 col-span-2">
                    <div className="flex items-center gap-1.5 text-muted-foreground">
                      <MapPin className="w-3.5 h-3.5" /> Location
                    </div>
                    <div className="font-medium text-foreground">{profile.birthPlace}</div>
                  </div>
                </div>

                <div className="pt-4 mt-4 border-t border-border/50 grid grid-cols-3 gap-2 text-center divide-x divide-border/50">
                  <div>
                    <div className="text-[10px] uppercase tracking-wider text-muted-foreground font-bold">Sun</div>
                    <div className="font-serif font-medium mt-1">{profile.sunSign}</div>
                  </div>
                  <div>
                    <div className="text-[10px] uppercase tracking-wider text-muted-foreground font-bold">Moon</div>
                    <div className="font-serif font-medium mt-1">{profile.moonSign}</div>
                  </div>
                  <div>
                    <div className="text-[10px] uppercase tracking-wider text-muted-foreground font-bold">Ascendant</div>
                    <div className="font-serif font-medium mt-1">{profile.ascendant}</div>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <ProfileDialog profile={profile} />
                  <DeleteProfileButton profileId={profile.id} profileName={profile.name} />
                </div>
              </CardContent>
            </Card>
          ))}
          
          {profiles?.length === 0 && (
            <div className="col-span-full text-center py-20 bg-card border border-dashed border-border rounded-xl">
              <User className="w-12 h-12 text-muted-foreground mx-auto mb-4 opacity-50" />
              <h3 className="font-serif text-xl text-foreground mb-2">No profiles yet</h3>
              <p className="text-muted-foreground text-sm mb-6">Create a profile to begin generating celestial readings.</p>
              <ProfileDialog />
            </div>
          )}
        </div>
      )}
    </div>
  );
}

function formatBirthDate(value: string) {
  const dateOnly = value.split("T")[0];
  const [year, month, day] = dateOnly.split("-");
  return year && month && day ? `${day}-${month}-${year}` : value;
}

function ProfileDialog({ profile }: { profile?: Profile }) {
  const [open, setOpen] = useState(false);
  const queryClient = useQueryClient();
  const createProfile = useCreateProfile();
  const updateProfile = useUpdateProfile();
  const isEditing = Boolean(profile);

  const form = useForm<ProfileFormValues>({
    resolver: zodResolver(profileSchema),
    defaultValues: {
      name: profile?.name ?? "",
      relationship: profile?.relationship ?? "Self",
      birthDate: profile ? profile.birthDate.split("T")[0] : "",
      birthTime: profile?.birthTime ?? "",
      birthPlace: profile?.birthPlace ?? "",
      timezone: profile?.timezone ?? "UTC",
      isApproximateTime: profile?.isApproximateTime ?? false,
    },
  });

  const onSubmit = (data: ProfileFormValues) => {
    const options = {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListProfilesQueryKey() });
        setOpen(false);
        form.reset();
      }
    };
    if (profile) {
      updateProfile.mutate({ profileId: profile.id, data }, options);
    } else {
      createProfile.mutate({ data }, options);
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button type="button" variant={isEditing ? "outline" : "default"} className="w-full gap-2 shadow-sm" onClick={() => setOpen(true)}>
          {isEditing ? <><Pencil className="w-4 h-4" /> Edit</> : <><Plus className="w-4 h-4" /> Add Profile</>}
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[500px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="font-serif text-2xl">{isEditing ? "Edit Birth Profile" : "Create Birth Profile"}</DialogTitle>
          <DialogDescription>
            Precise data is required for accurate planetary alignment calculations.
          </DialogDescription>
        </DialogHeader>
        
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-5 pt-4">
            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="name"
                render={({ field }) => (
                  <FormItem className="col-span-2 sm:col-span-1">
                    <FormLabel>Full Name</FormLabel>
                    <FormControl>
                      <Input placeholder="e.g. Maya Sharma" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="relationship"
                render={({ field }) => (
                  <FormItem className="col-span-2 sm:col-span-1">
                    <FormLabel>Relationship</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select..." />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="Self">Self</SelectItem>
                        <SelectItem value="Partner">Partner</SelectItem>
                        <SelectItem value="Child">Child</SelectItem>
                        <SelectItem value="Parent">Parent</SelectItem>
                        <SelectItem value="Friend">Friend</SelectItem>
                        <SelectItem value="Client">Client</SelectItem>
                        <SelectItem value="Other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="birthDate"
                render={({ field }) => (
                  <FormItem className="col-span-2 sm:col-span-1">
                    <FormLabel>Date of Birth</FormLabel>
                    <FormControl>
                      <Input type="date" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="birthTime"
                render={({ field }) => (
                  <FormItem className="col-span-2 sm:col-span-1">
                    <FormLabel>Time of Birth</FormLabel>
                    <FormControl>
                      <Input type="time" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <FormField
              control={form.control}
              name="isApproximateTime"
              render={({ field }) => (
                <FormItem className="flex flex-row items-center justify-between rounded-lg border border-border p-4 bg-muted/20">
                  <div className="space-y-0.5">
                    <FormLabel className="text-base">Approximate Time</FormLabel>
                    <FormDescription>
                      Check if the exact minute is unknown. We will use a wider orb for calculations.
                    </FormDescription>
                  </div>
                  <FormControl>
                    <Switch
                      checked={field.value}
                      onCheckedChange={field.onChange}
                    />
                  </FormControl>
                </FormItem>
              )}
            />

            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="birthPlace"
                render={({ field }) => (
                  <FormItem className="col-span-2 sm:col-span-1">
                    <FormLabel>City of Birth</FormLabel>
                    <FormControl>
                      <Input placeholder="e.g. New Delhi, India" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="timezone"
                render={({ field }) => (
                  <FormItem className="col-span-2 sm:col-span-1">
                    <FormLabel>Timezone</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select timezone..." />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="UTC">UTC</SelectItem>
                        <SelectItem value="Asia/Kolkata">IST (Asia/Kolkata)</SelectItem>
                        <SelectItem value="America/New_York">EST (America/New_York)</SelectItem>
                        <SelectItem value="Europe/London">EST (Europe/London)</SelectItem>
                        {/* More timezones would go here */}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            
            <DialogFooter className="pt-4">
              <Button type="button" variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
              <Button type="submit" disabled={createProfile.isPending || updateProfile.isPending}>
                {(createProfile.isPending || updateProfile.isPending) && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
                {isEditing ? "Update Profile" : "Save Profile"}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}

function DeleteProfileButton({ profileId, profileName }: { profileId: string; profileName: string }) {
  const queryClient = useQueryClient();
  const deleteProfile = useDeleteProfile();

  return (
    <AlertDialog>
      <AlertDialogTrigger asChild>
        <Button type="button" variant="outline" className="w-full gap-2 text-destructive hover:text-destructive">
          <Trash2 className="h-4 w-4" /> Delete profile
        </Button>
      </AlertDialogTrigger>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle>Delete {profileName}?</AlertDialogTitle>
          <AlertDialogDescription>
            This removes the saved birth profile. Existing purchased reports and payment records are kept.
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel>Cancel</AlertDialogCancel>
          <AlertDialogAction
            disabled={deleteProfile.isPending}
            onClick={() => deleteProfile.mutate(
              { profileId },
              { onSuccess: () => queryClient.invalidateQueries({ queryKey: getListProfilesQueryKey() }) },
            )}
            className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
          >
            {deleteProfile.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            Delete profile
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
}
