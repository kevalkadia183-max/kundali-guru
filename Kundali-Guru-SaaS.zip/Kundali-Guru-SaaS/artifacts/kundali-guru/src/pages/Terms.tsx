import { ScrollText } from "lucide-react";

export default function Terms() {
  return (
    <div className="max-w-3xl mx-auto py-16 px-6">
      <div className="text-center space-y-4 mb-16">
        <div className="w-16 h-16 bg-primary/10 text-primary rounded-full flex items-center justify-center mx-auto mb-6">
          <ScrollText className="w-8 h-8" />
        </div>
        <h1 className="text-4xl md:text-5xl font-serif text-foreground">Terms of Service</h1>
        <p className="text-xl text-muted-foreground">The principles of our practice.</p>
      </div>

      <div className="prose prose-stone dark:prose-invert max-w-none space-y-8 font-serif leading-relaxed">
        <section>
          <h2 className="text-2xl text-foreground font-serif">1. Nature of Astrological Consultation</h2>
          <p>
            Kundali Guru provides astrological calculations and interpretations based on traditional Vedic methodology. 
            These readings are intended for educational, philosophical, and personal reflection purposes only. 
            They do not constitute professional medical, legal, financial, or psychological advice.
          </p>
        </section>

        <section>
          <h2 className="text-2xl text-foreground font-serif">2. User Responsibilities</h2>
          <p>
            Users are responsible for providing accurate birth details. The precision of planetary alignment calculations 
            relies entirely on the exactness of the input data (Date, Time, and Location). We are not liable for inaccurate 
            readings resulting from incorrect profile information.
          </p>
        </section>

        <section>
          <h2 className="text-2xl text-foreground font-serif">3. Services & Payments</h2>
          <p>
            Certain in-depth reports and the Complete Analysis Bundle require a fee. Prices are clearly displayed prior to generation. 
            Once a personalized report is generated, the fee is non-refundable due to the bespoke computational nature of the service.
          </p>
        </section>
        
        <section>
          <h2 className="text-2xl text-foreground font-serif">4. Intellectual Property</h2>
          <p>
            The software, algorithms, report structures, and design interfaces of Kundali Guru are the intellectual property of our organization. 
            Users are granted a personal license to download and retain their generated PDF reports, but may not resell or systematically republish them.
          </p>
        </section>
      </div>
    </div>
  );
}
