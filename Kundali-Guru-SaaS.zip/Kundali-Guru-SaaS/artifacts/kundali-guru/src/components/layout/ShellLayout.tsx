import { ReactNode, useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { useClerk, useUser } from "@clerk/react";
import { Moon, Sun, Sparkles, BookOpen, User, Settings as SettingsIcon, Menu, LayoutDashboard, LogOut, Library, ShieldCheck } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet";

const links = [
  { href: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { href: "/profiles", label: "Profiles", icon: User },
  { href: "/reports", label: "Reading Room", icon: BookOpen },
  { href: "/my-reports", label: "My Reports", icon: Library },
  { href: "/account", label: "Account", icon: User },
  { href: "/settings", label: "Settings", icon: SettingsIcon },
];

const adminLink = { href: "/admin", label: "Admin Panel", icon: ShieldCheck };

function ThemeToggle() {
  const [theme, setTheme] = useState<"light" | "dark">("light");

  useEffect(() => {
    const isDark = document.documentElement.classList.contains("dark");
    setTheme(isDark ? "dark" : "light");
  }, []);

  const toggleTheme = () => {
    const newTheme = theme === "light" ? "dark" : "light";
    setTheme(newTheme);
    if (newTheme === "dark") {
      document.documentElement.classList.add("dark");
    } else {
      document.documentElement.classList.remove("dark");
    }
  };

  return (
    <Button variant="ghost" size="icon" onClick={toggleTheme} className="rounded-full text-foreground/80 hover:text-foreground hover:bg-muted/50 transition-colors">
      {theme === "light" ? <Moon className="w-4 h-4" /> : <Sun className="w-4 h-4" />}
    </Button>
  );
}

function Sidebar() {
  const [location] = useLocation();
  const { signOut } = useClerk();
  const { user } = useUser();
  const visibleLinks = user?.publicMetadata?.role === "admin" ? [...links, adminLink] : links;
  
  return (
    <aside className="w-64 bg-sidebar text-sidebar-foreground border-r border-sidebar-border hidden md:flex flex-col flex-shrink-0 z-20 h-screen sticky top-0">
      <div className="p-6 h-16 flex items-center shrink-0">
        <Link href="/dashboard" className="flex items-center gap-3 group transition-opacity hover:opacity-90">
          <div className="w-8 h-8 bg-sidebar-primary rounded-full flex items-center justify-center text-sidebar-primary-foreground shadow-sm">
            <Sparkles className="w-4 h-4" />
          </div>
          <span className="font-serif text-xl tracking-wide font-medium">Kundali Guru</span>
        </Link>
      </div>

      <div className="flex-1 overflow-y-auto py-4 px-3 flex flex-col gap-1">
        {visibleLinks.map((link) => {
          const isActive = location === link.href || (link.href !== "/dashboard" && location.startsWith(link.href) && link.href !== "/account");
          const Icon = link.icon;
          return (
            <Link key={link.href} href={link.href}>
              <div
                className={cn(
                  "flex items-center gap-3 px-3 py-2.5 rounded-md text-sm font-medium transition-all cursor-pointer",
                  isActive
                    ? "bg-sidebar-accent text-sidebar-accent-foreground shadow-sm"
                    : "text-sidebar-foreground/70 hover:bg-sidebar-accent/50 hover:text-sidebar-foreground"
                )}
              >
                <Icon className="w-4 h-4" />
                {link.label}
              </div>
            </Link>
          );
        })}
      </div>

      <div className="p-4 mt-auto border-t border-sidebar-border/50">
        <button 
          onClick={() => signOut({ redirectUrl: "/" })}
          className="flex w-full items-center gap-3 px-3 py-2.5 rounded-md text-sm font-medium transition-colors text-sidebar-foreground/70 hover:bg-sidebar-accent/50 hover:text-sidebar-foreground cursor-pointer"
        >
          <LogOut className="w-4 h-4" />
          Logout
        </button>
      </div>
    </aside>
  );
}

function MobileNav() {
  const [isOpen, setIsOpen] = useState(false);
  const [location] = useLocation();
  const { signOut } = useClerk();
  const { user } = useUser();
  const visibleLinks = user?.publicMetadata?.role === "admin" ? [...links, adminLink] : links;
  
  useEffect(() => {
    setIsOpen(false);
  }, [location]);

  return (
    <Sheet open={isOpen} onOpenChange={setIsOpen}>
      <SheetTrigger asChild>
        <Button type="button" variant="ghost" size="icon" className="md:hidden" aria-label="Open navigation menu">
          <Menu className="w-5 h-5" />
        </Button>
      </SheetTrigger>
      <SheetContent side="left" className="w-72 p-0 bg-sidebar text-sidebar-foreground flex flex-col">
        <SheetHeader className="p-4 border-b border-sidebar-border">
          <SheetTitle className="flex items-center gap-3 text-sidebar-foreground">
            <span className="w-8 h-8 bg-sidebar-primary rounded-full flex items-center justify-center text-sidebar-primary-foreground">
              <Sparkles className="w-4 h-4" />
            </span>
            <span className="font-serif text-lg tracking-wide">Kundali Guru</span>
          </SheetTitle>
        </SheetHeader>
            <div className="flex-1 overflow-y-auto py-4 px-3 flex flex-col gap-1">
              {visibleLinks.map((link) => {
                const isActive = location === link.href || (link.href !== "/dashboard" && location.startsWith(link.href) && link.href !== "/account");
                const Icon = link.icon;
                return (
                  <Link key={link.href} href={link.href} onClick={() => setIsOpen(false)}>
                    <div
                      className={cn(
                        "flex items-center gap-3 px-3 py-2.5 rounded-md text-sm font-medium transition-all cursor-pointer",
                        isActive
                          ? "bg-sidebar-accent text-sidebar-accent-foreground"
                          : "text-sidebar-foreground/70 hover:bg-sidebar-accent/50 hover:text-sidebar-foreground"
                      )}
                    >
                      <Icon className="w-4 h-4" />
                      {link.label}
                    </div>
                  </Link>
                );
              })}
            </div>

            <div className="p-4 border-t border-sidebar-border/50">
              <button 
                onClick={() => signOut({ redirectUrl: "/" })}
                className="flex w-full items-center gap-3 px-3 py-2.5 rounded-md text-sm font-medium transition-colors text-sidebar-foreground/70 hover:bg-sidebar-accent/50 hover:text-sidebar-foreground cursor-pointer"
              >
                <LogOut className="w-4 h-4" />
                Logout
              </button>
            </div>
      </SheetContent>
    </Sheet>
  );
}

function TopNav() {
  const { user } = useUser();
  const [location] = useLocation();

  const getPageTitle = () => {
    if (location === "/dashboard") return "Dashboard";
    if (location.startsWith("/profiles")) return "Profiles";
    if (location.startsWith("/reports")) return "Reading Room";
    if (location.startsWith("/my-reports")) return "My Reports";
    if (location.startsWith("/account")) return "Account";
    if (location.startsWith("/settings")) return "Settings";
    if (location.startsWith("/admin")) return "Admin Panel";
    return "Celestial Study";
  };

  const initials = user?.firstName && user?.lastName 
    ? `${user.firstName[0]}${user.lastName[0]}`
    : user?.firstName 
      ? user.firstName[0]
      : "US";

  return (
    <header className="h-16 border-b border-border flex items-center justify-between px-4 md:px-8 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/80 sticky top-0 z-10 shrink-0">
      <div className="flex items-center gap-3">
        <MobileNav />
        <span className="font-serif font-medium md:hidden">Kundali Guru</span>
        <span className="hidden md:block font-serif text-muted-foreground text-sm tracking-wide uppercase">
          {getPageTitle()}
        </span>
      </div>
      
      <div className="flex items-center gap-3">
        <ThemeToggle />
        <Link href="/account" className="flex items-center justify-center w-8 h-8 rounded-full bg-primary/10 border border-primary/20 text-primary text-sm font-semibold hover:bg-primary/20 transition-colors cursor-pointer ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring">
          {initials.toUpperCase()}
        </Link>
      </div>
    </header>
  );
}

export function ShellLayout({ children }: { children: ReactNode }) {
  return (
    <div className="flex min-h-screen bg-background text-foreground font-sans">
      <Sidebar />
      <div className="flex-1 flex flex-col min-w-0 max-w-full h-screen overflow-y-auto">
        <TopNav />
        <main className="flex-1 p-4 md:p-8 lg:p-12 w-full max-w-6xl mx-auto">
          {children}
        </main>
      </div>
    </div>
  );
}

export function PublicLayout({ children, hideNav = false }: { children: ReactNode, hideNav?: boolean }) {
  return (
    <div className="min-h-screen bg-background text-foreground font-sans flex flex-col">
      {!hideNav && (
        <header className="h-20 border-b border-border flex items-center justify-between px-6 md:px-12 bg-background/80 backdrop-blur-sm sticky top-0 z-10">
          <Link href="/" className="flex items-center gap-3 group transition-opacity hover:opacity-90">
            <div className="w-10 h-10 bg-primary rounded-full flex items-center justify-center text-primary-foreground shadow-md">
              <Sparkles className="w-5 h-5" />
            </div>
            <span className="font-serif text-2xl tracking-wide font-medium">Kundali Guru</span>
          </Link>
          <div className="flex items-center gap-6">
            <ThemeToggle />
            <div className="hidden sm:flex items-center gap-4">
              <Link href="/sign-in" className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors">
                Sign In
              </Link>
              <Link href="/sign-up">
                <Button className="font-medium shadow-sm">Get Started</Button>
              </Link>
            </div>
          </div>
        </header>
      )}
      <main className="flex-1 flex flex-col">
        {children}
      </main>
      <footer className="py-8 border-t border-border mt-auto bg-card">
        <div className="max-w-6xl mx-auto px-6 text-center text-sm text-muted-foreground flex flex-col md:flex-row items-center justify-between gap-4">
          <span>&copy; {new Date().getFullYear()} Kundali Guru. All rights reserved.</span>
          <div className="flex items-center gap-6">
            <Link href="/terms" className="hover:text-foreground transition-colors">Terms of Service</Link>
            <Link href="/privacy" className="hover:text-foreground transition-colors">Privacy Policy</Link>
          </div>
        </div>
      </footer>
    </div>
  );
}
