import {
  jsonb,
  index,
  pgTable,
  text,
  timestamp,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { LEGACY_UNOWNED_USER_ID } from "./profiles";

export type StoredReportSection = {
  id: string;
  title: string;
  eyebrow: string;
  content: string;
  tone: "neutral" | "positive" | "caution";
};

export type LifeJourneyDomain = {
  id: string;
  name: string;
  summary: string;
  currentPeriod: string;
  futureWindow: string;
  challenge: string;
  remedy: string;
  points: Array<{ age: number; year: number; score: number; period: string }>;
};

export const reportsTable = pgTable(
  "reports",
  {
    id: text("id").primaryKey(),
    userId: text("user_id").notNull().default(LEGACY_UNOWNED_USER_ID),
    profileId: text("profile_id").notNull(),
    profileName: text("profile_name").notNull(),
    productId: text("product_id").notNull(),
    productName: text("product_name").notNull(),
    status: text("status").notNull().default("ready"),
    generatedAt: timestamp("generated_at", { withTimezone: true }).notNull().defaultNow(),
    summary: text("summary").notNull(),
    question: text("question").notNull(),
    sections: jsonb("sections").$type<StoredReportSection[]>().notNull(),
    lifeJourney: jsonb("life_journey").$type<LifeJourneyDomain[]>().notNull().default([]),
    disclaimer: text("disclaimer").notNull().default("For guidance and reflective purposes only. Not a substitute for professional financial, legal, or medical advice."),
  },
  (table) => [
    index("reports_user_id_idx").on(table.userId),
    index("reports_user_profile_idx").on(table.userId, table.profileId),
  ],
);

export const insertReportSchema = createInsertSchema(reportsTable);
export type InsertReport = z.infer<typeof insertReportSchema>;
export type Report = typeof reportsTable.$inferSelect;